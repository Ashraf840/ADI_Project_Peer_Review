﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    public partial class frmReviewer : Form
    {

        PeerReviewEntities db = new PeerReviewEntities();

        public frmReviewer()
        {
            InitializeComponent();
        }

        private void frmReviewer_Load(object sender, EventArgs e)
        {
            txtbxReviewerName.Text = clsUserData.UserName;
            txtbxReviewerEmail.Text = clsUserData.UserEmail;

            //show all the skills stored inside the "Skill" table of the database
            //Select the "Skill" table's "Id" & "Name" field in particular, store that into the "data" variable
            var data = db.Skills.Select(d => new { d.Id, d.Name }).ToList();

            //the listbox "lstbxAuthrSkill" will get the data from "data"
            lstbxReviewerSkill.DataSource = data;
            //DisplayMember, the listbox "lstbxReviewerSkill" shows the value fetched from the "Skill" table.
            lstbxReviewerSkill.DisplayMember = "Name";
            //ValueMember, the listbox "lstbxReviewerSkill" returns the Id values of selected properties of the "Skill" table.
            lstbxReviewerSkill.ValueMember = "Id";
            //select option is set to Multiselection.
            lstbxReviewerSkill.SelectionMode = SelectionMode.MultiSimple;
            //disselect any property from the "lstbxReviewerSkill" listBox by default
            lstbxReviewerSkill.SelectedIndex = -1;
            //by default, disable the "btnSubmit" submit-button while the form loads 
            btnSubmit.Enabled = false;


        }

        private void lstbxReviewerSkill_Enter(object sender, EventArgs e)
        {
            btnSubmit.Enabled = true;
            btnSubmit.Cursor = Cursors.Hand;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                ////find the specific reviewer regarding his name in the reviewer table, and store that inside a var datatype named "revInfo"
                var revInfo = db.Reviewers.Where(d => d.Name == txtbxReviewerName.Text).FirstOrDefault();

                //if the reviewertable doesn't contain that specific row of data, then insert the folowwing data to the reviewer table's row (auhtor table doesn;t contain the specific data)
                if (revInfo == null)
                {
                    //filling up that author information only inside the author table in DB (Author)
                    Reviewer reviewr = new Reviewer()
                    {
                        Name = txtbxReviewerName.Text,
                        Email = txtbxReviewerEmail.Text,
                        DOB = dtpReviewerDOB.Value,
                        usrId = clsUserData.UserId
                    };

                    db.Reviewers.Add(reviewr);
                    db.SaveChanges();

                    //after successfully inserted data inside the "Reviewer", displays the Id of that reviewer regarding the Id (inside reviewer tbl) in which the reviewer's data get inserted
                    txtbxReviewerId.Text = reviewr.Id.ToString();

                    //filling up the skill names regarding individual authors ("AuthorSkill")
                    foreach (object item in lstbxReviewerSkill.SelectedItems)
                    {
                        //MessageBox.Show(item.ToString());
                        string idn = item.ToString().Split(',')[0].Substring(6);

                        ReviewerSkill reviewrSkl = new ReviewerSkill();
                        reviewrSkl.reviewerId = reviewr.Id;
                        reviewrSkl.skillId = Int32.Parse(idn);

                        db.ReviewerSkills.Add(reviewrSkl);
                        db.SaveChanges();
                    }
                    MessageBox.Show("Reviewer & Skill Data Inserted successfully ....");
                }
                //but if the reviewer table does contain that specific data, don't have to input data about that reviewer, rather only input data regarding his/her skills
                else
                {
                    //if the user has a data-row inside "Reviewer" table, then store that Id isnide the reviewer id text-field
                    txtbxReviewerId.Text = revInfo.Id.ToString();

                    //Reviewer skill insert only
                    foreach (object item in lstbxReviewerSkill.SelectedItems)
                    {
                        //MessageBox.Show(item.ToString());
                        string idn = item.ToString().Split(',')[0].Substring(6);
                        int idNum = Int32.Parse(idn);

                        //find the specific data from "ReviewerSkill" table regarding their reviewerId & skillId, and store that inside a var named "authrSkl"
                        var reviewrSkl = db.ReviewerSkills.Where(d => d.reviewerId == revInfo.Id && d.skillId == idNum).FirstOrDefault();

                        if (reviewrSkl == null)
                        {
                            ReviewerSkill reviewrSkill = new ReviewerSkill();
                            reviewrSkill.reviewerId = revInfo.Id;
                            reviewrSkill.skillId = idNum;

                            db.ReviewerSkills.Add(reviewrSkill);
                            db.SaveChanges();

                            if (reviewrSkill.Id != 0)
                            {
                                MessageBox.Show("Only Skill Data Inserted Successfully....", "Successful",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        //but if the similar reviewerId coresponding its SkillId is already there, the system will not insert similar skills according their skillIds
                        else
                        {
                            MessageBox.Show("Similar Skills alreaady existed!", "Warning",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Data insert unsuccessful!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
