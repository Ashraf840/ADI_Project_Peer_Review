﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    public partial class frmResearchWork : Form
    {

        string sourceFile;
        PeerReviewEntities db = new PeerReviewEntities();
        string authorId = "";

        public frmResearchWork()
        {
            InitializeComponent();
        }

        private void frmResearchWork_Load(object sender, EventArgs e)
        {
            //chosen skills of the that specific author is automatically shown in the "skill" comboBox
            //it checks whether that specific author is found or not by applying the "Where()" function in the "db.Author"
            var authrData = db.Authors.Where(d => d.usrId == clsUserData.UserId).FirstOrDefault();

            //--------------------Testing--------------------
            //MessageBox.Show(Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10)));
            //--------------------Testing--------------------

            if (authrData == null)
            {
                MessageBox.Show("No Author Found ..!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
            }
            else
            {
                authorId = authrData.Id.ToString();

                //var aId = db.Authors.Where(d => d.usrId == clsUserData.UserId).FirstOrDefault();   [ not NECESSARY ]

                //every skill including their name of that author is fetched from the "AuthorSKill" table of the DB and stored inside the var dataType "authrSkill"
                var authrSkill = db.AuthorSkills.Select(d => new { d.AuthrId, d.SkillId, SkillName = d.Skill.Name }).Where(d => d.AuthrId == authrData.Id).ToList();

                cbobxRWrkSkill.DataSource = authrSkill;
                cbobxRWrkSkill.DisplayMember = "SkillName";
                cbobxRWrkSkill.ValueMember = "SkillId"; 

                btnSubmit.Enabled = false;
            }
        }

        private void btnBrowserFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.InitialDirectory = "C:\\";
            openFileDialog.Title = "Select a file to upload";
            openFileDialog.Filter = "Document(*.pdf; *.doc) | *.pdf; *.docx";
            openFileDialog.FilterIndex = 1;

            try
            {
                if (openFileDialog.ShowDialog() != DialogResult.Cancel)
                {
                    if (openFileDialog.CheckFileExists)
                    {
                        string path = System.IO.Path.GetFullPath(openFileDialog.FileName);
                        //stores the full path of the file into "sourceFile", which will be used in choosing 
                        //the "sourceFileDestination" during uploading a file in "btnSubmit" section
                        sourceFile = path;
                        string fileName = System.IO.Path.GetFileName(openFileDialog.FileName);
                        txtbxRWrkDocName.Text = fileName;

                        string ext = System.IO.Path.GetExtension(openFileDialog.FileName);
                        txtbxRWrkDocType.Text = ext.Substring(1);

                        btnSubmit.Enabled = txtbxRWrkDocName.Text != "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtbxRWrkDocName.Text == null)
                {
                    MessageBox.Show("Please select a valid file ....!");
                }
                else
                {
                    //------------Data (Research Doc Data) insert inside DB------------
                    ResearchWork resrch = new ResearchWork();
                    resrch.Doc = txtbxRWrkDocName.Text;
                    resrch.uDate = dtpRWrkUpldDate.Value;
                    resrch.dType = txtbxRWrkDocType.Text;
                    resrch.skillId = Int32.Parse(cbobxRWrkSkill.SelectedValue.ToString());   //***************************************//
                    resrch.authrId = Int32.Parse(authorId);
                    resrch.isReviewer = false;

                    db.ResearchWorks.Add(resrch);
                    db.SaveChanges();

                    txtbxRWrkId.Text = resrch.Id.ToString();


                    //----------------File Upload (inside a system.dir)----------------

                    //the full directory path( *\PeerReview_00163492\bin\Debug), so substring(startIndex, int.length) 
                    //used here, cuts down the "\bin\Debug" from the directory, so that the system can upload any 
                    //file naming "Upload" which is inside the PeerReview system's root directory. 
                    //It's used to set the upload destination dir.
                    string path = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));

                    //this copies an existing file to a new file, Overwriting a file of the same name is allowed, 
                    //bcz this method is set to "true" at the last section
                    System.IO.File.Copy(sourceFile, path + "\\Upload\\" + txtbxRWrkDocName.Text);


                    //----------------Insert Data into "DocumentTag" table of the DB----------------

                    DocumentTag docTag = new DocumentTag();

                    docTag.docId = resrch.Id;
                    docTag.skillId = (int)resrch.skillId;

                    db.DocumentTags.Add(docTag);
                    db.SaveChanges();

                    MessageBox.Show("Document Uploaded Successfully ...", "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("File already exists !!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //MessageBox.Show("Document Upload Failed!", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
