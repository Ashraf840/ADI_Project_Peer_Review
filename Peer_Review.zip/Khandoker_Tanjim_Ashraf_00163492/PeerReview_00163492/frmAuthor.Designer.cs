﻿namespace PeerReview_00163492
{
    partial class frmAuthor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lstbxAuthrSkill = new System.Windows.Forms.ListBox();
            this.dtpAuthrDOB = new System.Windows.Forms.DateTimePicker();
            this.lblAuthrDOB = new System.Windows.Forms.Label();
            this.txtbxAuthrEmail = new System.Windows.Forms.TextBox();
            this.lblAuthrEmail = new System.Windows.Forms.Label();
            this.txtbxAuthrName = new System.Windows.Forms.TextBox();
            this.lblAuthrSkill = new System.Windows.Forms.Label();
            this.txtbxAuthrId = new System.Windows.Forms.TextBox();
            this.lblAuthrName = new System.Windows.Forms.Label();
            this.lblAuthrId = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lstbxAuthrSkill);
            this.groupBox1.Controls.Add(this.dtpAuthrDOB);
            this.groupBox1.Controls.Add(this.lblAuthrDOB);
            this.groupBox1.Controls.Add(this.txtbxAuthrEmail);
            this.groupBox1.Controls.Add(this.lblAuthrEmail);
            this.groupBox1.Controls.Add(this.txtbxAuthrName);
            this.groupBox1.Controls.Add(this.lblAuthrSkill);
            this.groupBox1.Controls.Add(this.txtbxAuthrId);
            this.groupBox1.Controls.Add(this.lblAuthrName);
            this.groupBox1.Controls.Add(this.lblAuthrId);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(388, 346);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Author Information";
            // 
            // lstbxAuthrSkill
            // 
            this.lstbxAuthrSkill.FormattingEnabled = true;
            this.lstbxAuthrSkill.ItemHeight = 16;
            this.lstbxAuthrSkill.Location = new System.Drawing.Point(156, 211);
            this.lstbxAuthrSkill.Name = "lstbxAuthrSkill";
            this.lstbxAuthrSkill.Size = new System.Drawing.Size(221, 116);
            this.lstbxAuthrSkill.TabIndex = 8;
            this.lstbxAuthrSkill.Enter += new System.EventHandler(this.lstbxAuthrSkill_Enter);
            // 
            // dtpAuthrDOB
            // 
            this.dtpAuthrDOB.CustomFormat = "yyyy/MM/dd";
            this.dtpAuthrDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpAuthrDOB.Location = new System.Drawing.Point(156, 169);
            this.dtpAuthrDOB.Name = "dtpAuthrDOB";
            this.dtpAuthrDOB.Size = new System.Drawing.Size(124, 22);
            this.dtpAuthrDOB.TabIndex = 3;
            // 
            // lblAuthrDOB
            // 
            this.lblAuthrDOB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAuthrDOB.Location = new System.Drawing.Point(20, 169);
            this.lblAuthrDOB.Name = "lblAuthrDOB";
            this.lblAuthrDOB.Size = new System.Drawing.Size(115, 25);
            this.lblAuthrDOB.TabIndex = 0;
            this.lblAuthrDOB.Text = "Date of Birth:";
            this.lblAuthrDOB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbxAuthrEmail
            // 
            this.txtbxAuthrEmail.Location = new System.Drawing.Point(156, 127);
            this.txtbxAuthrEmail.Name = "txtbxAuthrEmail";
            this.txtbxAuthrEmail.Size = new System.Drawing.Size(221, 22);
            this.txtbxAuthrEmail.TabIndex = 2;
            // 
            // lblAuthrEmail
            // 
            this.lblAuthrEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAuthrEmail.Location = new System.Drawing.Point(20, 127);
            this.lblAuthrEmail.Name = "lblAuthrEmail";
            this.lblAuthrEmail.Size = new System.Drawing.Size(115, 25);
            this.lblAuthrEmail.TabIndex = 0;
            this.lblAuthrEmail.Text = "Email:";
            this.lblAuthrEmail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbxAuthrName
            // 
            this.txtbxAuthrName.Location = new System.Drawing.Point(156, 85);
            this.txtbxAuthrName.Name = "txtbxAuthrName";
            this.txtbxAuthrName.Size = new System.Drawing.Size(221, 22);
            this.txtbxAuthrName.TabIndex = 1;
            // 
            // lblAuthrSkill
            // 
            this.lblAuthrSkill.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAuthrSkill.Location = new System.Drawing.Point(20, 211);
            this.lblAuthrSkill.Name = "lblAuthrSkill";
            this.lblAuthrSkill.Size = new System.Drawing.Size(115, 25);
            this.lblAuthrSkill.TabIndex = 0;
            this.lblAuthrSkill.Text = "Skill(s):";
            this.lblAuthrSkill.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbxAuthrId
            // 
            this.txtbxAuthrId.Location = new System.Drawing.Point(156, 43);
            this.txtbxAuthrId.Name = "txtbxAuthrId";
            this.txtbxAuthrId.ReadOnly = true;
            this.txtbxAuthrId.Size = new System.Drawing.Size(100, 22);
            this.txtbxAuthrId.TabIndex = 7;
            // 
            // lblAuthrName
            // 
            this.lblAuthrName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAuthrName.Location = new System.Drawing.Point(20, 85);
            this.lblAuthrName.Name = "lblAuthrName";
            this.lblAuthrName.Size = new System.Drawing.Size(115, 25);
            this.lblAuthrName.TabIndex = 0;
            this.lblAuthrName.Text = "Author Name:";
            this.lblAuthrName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblAuthrId
            // 
            this.lblAuthrId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAuthrId.Location = new System.Drawing.Point(20, 43);
            this.lblAuthrId.Name = "lblAuthrId";
            this.lblAuthrId.Size = new System.Drawing.Size(115, 25);
            this.lblAuthrId.TabIndex = 0;
            this.lblAuthrId.Text = "Author Id:";
            this.lblAuthrId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(105, 373);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(83, 34);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(12, 373);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(83, 34);
            this.btnSubmit.TabIndex = 4;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // frmAuthor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 428);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSubmit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAuthor";
            this.Text = "Author";
            this.Load += new System.EventHandler(this.frmAuthor_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtbxAuthrName;
        private System.Windows.Forms.Label lblAuthrSkill;
        private System.Windows.Forms.TextBox txtbxAuthrId;
        private System.Windows.Forms.Label lblAuthrName;
        private System.Windows.Forms.Label lblAuthrId;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.DateTimePicker dtpAuthrDOB;
        private System.Windows.Forms.Label lblAuthrDOB;
        private System.Windows.Forms.TextBox txtbxAuthrEmail;
        private System.Windows.Forms.Label lblAuthrEmail;
        private System.Windows.Forms.ListBox lstbxAuthrSkill;
    }
}