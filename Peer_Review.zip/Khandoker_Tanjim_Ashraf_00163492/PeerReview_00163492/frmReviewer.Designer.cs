﻿namespace PeerReview_00163492
{
    partial class frmReviewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lstbxReviewerSkill = new System.Windows.Forms.ListBox();
            this.dtpReviewerDOB = new System.Windows.Forms.DateTimePicker();
            this.lblReviewerDOB = new System.Windows.Forms.Label();
            this.txtbxReviewerEmail = new System.Windows.Forms.TextBox();
            this.lblReviewerEmail = new System.Windows.Forms.Label();
            this.txtbxReviewerName = new System.Windows.Forms.TextBox();
            this.lblReviewerSkill = new System.Windows.Forms.Label();
            this.txtbxReviewerId = new System.Windows.Forms.TextBox();
            this.lblReviewerName = new System.Windows.Forms.Label();
            this.lblReviewerId = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lstbxReviewerSkill);
            this.groupBox1.Controls.Add(this.dtpReviewerDOB);
            this.groupBox1.Controls.Add(this.lblReviewerDOB);
            this.groupBox1.Controls.Add(this.txtbxReviewerEmail);
            this.groupBox1.Controls.Add(this.lblReviewerEmail);
            this.groupBox1.Controls.Add(this.txtbxReviewerName);
            this.groupBox1.Controls.Add(this.lblReviewerSkill);
            this.groupBox1.Controls.Add(this.txtbxReviewerId);
            this.groupBox1.Controls.Add(this.lblReviewerName);
            this.groupBox1.Controls.Add(this.lblReviewerId);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(388, 346);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Reviewer Information";
            // 
            // lstbxReviewerSkill
            // 
            this.lstbxReviewerSkill.FormattingEnabled = true;
            this.lstbxReviewerSkill.ItemHeight = 16;
            this.lstbxReviewerSkill.Location = new System.Drawing.Point(156, 211);
            this.lstbxReviewerSkill.Name = "lstbxReviewerSkill";
            this.lstbxReviewerSkill.Size = new System.Drawing.Size(221, 116);
            this.lstbxReviewerSkill.TabIndex = 8;
            this.lstbxReviewerSkill.Enter += new System.EventHandler(this.lstbxReviewerSkill_Enter);
            // 
            // dtpReviewerDOB
            // 
            this.dtpReviewerDOB.CustomFormat = "yyyy/MM/dd";
            this.dtpReviewerDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpReviewerDOB.Location = new System.Drawing.Point(156, 169);
            this.dtpReviewerDOB.Name = "dtpReviewerDOB";
            this.dtpReviewerDOB.Size = new System.Drawing.Size(124, 22);
            this.dtpReviewerDOB.TabIndex = 3;
            // 
            // lblReviewerDOB
            // 
            this.lblReviewerDOB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblReviewerDOB.Location = new System.Drawing.Point(20, 169);
            this.lblReviewerDOB.Name = "lblReviewerDOB";
            this.lblReviewerDOB.Size = new System.Drawing.Size(115, 25);
            this.lblReviewerDOB.TabIndex = 0;
            this.lblReviewerDOB.Text = "Date of Birth:";
            this.lblReviewerDOB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbxReviewerEmail
            // 
            this.txtbxReviewerEmail.Location = new System.Drawing.Point(156, 127);
            this.txtbxReviewerEmail.Name = "txtbxReviewerEmail";
            this.txtbxReviewerEmail.Size = new System.Drawing.Size(221, 22);
            this.txtbxReviewerEmail.TabIndex = 2;
            // 
            // lblReviewerEmail
            // 
            this.lblReviewerEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblReviewerEmail.Location = new System.Drawing.Point(20, 127);
            this.lblReviewerEmail.Name = "lblReviewerEmail";
            this.lblReviewerEmail.Size = new System.Drawing.Size(115, 25);
            this.lblReviewerEmail.TabIndex = 0;
            this.lblReviewerEmail.Text = "Email:";
            this.lblReviewerEmail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbxReviewerName
            // 
            this.txtbxReviewerName.Location = new System.Drawing.Point(156, 85);
            this.txtbxReviewerName.Name = "txtbxReviewerName";
            this.txtbxReviewerName.Size = new System.Drawing.Size(221, 22);
            this.txtbxReviewerName.TabIndex = 1;
            // 
            // lblReviewerSkill
            // 
            this.lblReviewerSkill.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblReviewerSkill.Location = new System.Drawing.Point(20, 211);
            this.lblReviewerSkill.Name = "lblReviewerSkill";
            this.lblReviewerSkill.Size = new System.Drawing.Size(115, 25);
            this.lblReviewerSkill.TabIndex = 0;
            this.lblReviewerSkill.Text = "Skill(s):";
            this.lblReviewerSkill.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbxReviewerId
            // 
            this.txtbxReviewerId.Location = new System.Drawing.Point(156, 43);
            this.txtbxReviewerId.Name = "txtbxReviewerId";
            this.txtbxReviewerId.ReadOnly = true;
            this.txtbxReviewerId.Size = new System.Drawing.Size(100, 22);
            this.txtbxReviewerId.TabIndex = 7;
            // 
            // lblReviewerName
            // 
            this.lblReviewerName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblReviewerName.Location = new System.Drawing.Point(20, 85);
            this.lblReviewerName.Name = "lblReviewerName";
            this.lblReviewerName.Size = new System.Drawing.Size(115, 25);
            this.lblReviewerName.TabIndex = 0;
            this.lblReviewerName.Text = "Reviewer Name:";
            this.lblReviewerName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblReviewerId
            // 
            this.lblReviewerId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblReviewerId.Location = new System.Drawing.Point(20, 43);
            this.lblReviewerId.Name = "lblReviewerId";
            this.lblReviewerId.Size = new System.Drawing.Size(115, 25);
            this.lblReviewerId.TabIndex = 0;
            this.lblReviewerId.Text = "Reviewer Id:";
            this.lblReviewerId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(105, 373);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(83, 34);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(12, 373);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(83, 34);
            this.btnSubmit.TabIndex = 6;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // frmReviewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 428);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSubmit);
            this.Name = "frmReviewer";
            this.Text = "Reviewer";
            this.Load += new System.EventHandler(this.frmReviewer_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox lstbxReviewerSkill;
        private System.Windows.Forms.DateTimePicker dtpReviewerDOB;
        private System.Windows.Forms.Label lblReviewerDOB;
        private System.Windows.Forms.TextBox txtbxReviewerEmail;
        private System.Windows.Forms.Label lblReviewerEmail;
        private System.Windows.Forms.TextBox txtbxReviewerName;
        private System.Windows.Forms.Label lblReviewerSkill;
        private System.Windows.Forms.TextBox txtbxReviewerId;
        private System.Windows.Forms.Label lblReviewerName;
        private System.Windows.Forms.Label lblReviewerId;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSubmit;
    }
}