﻿namespace PeerReview_00163492
{
    partial class frmResearchWork
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRWrkId = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtbxRWrkDocName = new System.Windows.Forms.TextBox();
            this.lblRWrkSkill = new System.Windows.Forms.Label();
            this.txtbxRWrkId = new System.Windows.Forms.TextBox();
            this.lblRWrkDocName = new System.Windows.Forms.Label();
            this.btnBrowserFile = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.dtpRWrkUpldDate = new System.Windows.Forms.DateTimePicker();
            this.lblRWrkUpldDate = new System.Windows.Forms.Label();
            this.cbobxRWrkSkill = new System.Windows.Forms.ComboBox();
            this.lblRWrkDocType = new System.Windows.Forms.Label();
            this.txtbxRWrkDocType = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblRWrkId
            // 
            this.lblRWrkId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRWrkId.Location = new System.Drawing.Point(20, 45);
            this.lblRWrkId.Name = "lblRWrkId";
            this.lblRWrkId.Size = new System.Drawing.Size(133, 25);
            this.lblRWrkId.TabIndex = 0;
            this.lblRWrkId.Text = "Id:";
            this.lblRWrkId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbobxRWrkSkill);
            this.groupBox1.Controls.Add(this.dtpRWrkUpldDate);
            this.groupBox1.Controls.Add(this.lblRWrkUpldDate);
            this.groupBox1.Controls.Add(this.txtbxRWrkDocType);
            this.groupBox1.Controls.Add(this.txtbxRWrkDocName);
            this.groupBox1.Controls.Add(this.lblRWrkSkill);
            this.groupBox1.Controls.Add(this.txtbxRWrkId);
            this.groupBox1.Controls.Add(this.lblRWrkDocType);
            this.groupBox1.Controls.Add(this.lblRWrkDocName);
            this.groupBox1.Controls.Add(this.lblRWrkId);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(438, 280);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Research Work Upload";
            // 
            // txtbxRWrkDocName
            // 
            this.txtbxRWrkDocName.Location = new System.Drawing.Point(200, 88);
            this.txtbxRWrkDocName.Name = "txtbxRWrkDocName";
            this.txtbxRWrkDocName.ReadOnly = true;
            this.txtbxRWrkDocName.Size = new System.Drawing.Size(232, 22);
            this.txtbxRWrkDocName.TabIndex = 0;
            // 
            // lblRWrkSkill
            // 
            this.lblRWrkSkill.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRWrkSkill.Location = new System.Drawing.Point(17, 217);
            this.lblRWrkSkill.Name = "lblRWrkSkill";
            this.lblRWrkSkill.Size = new System.Drawing.Size(133, 25);
            this.lblRWrkSkill.TabIndex = 0;
            this.lblRWrkSkill.Text = "Skill:";
            this.lblRWrkSkill.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbxRWrkId
            // 
            this.txtbxRWrkId.Location = new System.Drawing.Point(200, 46);
            this.txtbxRWrkId.Name = "txtbxRWrkId";
            this.txtbxRWrkId.ReadOnly = true;
            this.txtbxRWrkId.Size = new System.Drawing.Size(100, 22);
            this.txtbxRWrkId.TabIndex = 0;
            // 
            // lblRWrkDocName
            // 
            this.lblRWrkDocName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRWrkDocName.Location = new System.Drawing.Point(20, 88);
            this.lblRWrkDocName.Name = "lblRWrkDocName";
            this.lblRWrkDocName.Size = new System.Drawing.Size(133, 25);
            this.lblRWrkDocName.TabIndex = 0;
            this.lblRWrkDocName.Text = "Document Name:";
            this.lblRWrkDocName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnBrowserFile
            // 
            this.btnBrowserFile.Location = new System.Drawing.Point(172, 315);
            this.btnBrowserFile.Name = "btnBrowserFile";
            this.btnBrowserFile.Size = new System.Drawing.Size(154, 34);
            this.btnBrowserFile.TabIndex = 1;
            this.btnBrowserFile.Text = "&Browse File";
            this.btnBrowserFile.UseVisualStyleBackColor = true;
            this.btnBrowserFile.Click += new System.EventHandler(this.btnBrowserFile_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(12, 315);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(154, 34);
            this.btnSubmit.TabIndex = 3;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // dtpRWrkUpldDate
            // 
            this.dtpRWrkUpldDate.CustomFormat = "yyyy/MM/dd";
            this.dtpRWrkUpldDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpRWrkUpldDate.Location = new System.Drawing.Point(200, 131);
            this.dtpRWrkUpldDate.Name = "dtpRWrkUpldDate";
            this.dtpRWrkUpldDate.Size = new System.Drawing.Size(124, 22);
            this.dtpRWrkUpldDate.TabIndex = 4;
            // 
            // lblRWrkUpldDate
            // 
            this.lblRWrkUpldDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRWrkUpldDate.Location = new System.Drawing.Point(20, 131);
            this.lblRWrkUpldDate.Name = "lblRWrkUpldDate";
            this.lblRWrkUpldDate.Size = new System.Drawing.Size(133, 25);
            this.lblRWrkUpldDate.TabIndex = 0;
            this.lblRWrkUpldDate.Text = "Uplaod Date:";
            this.lblRWrkUpldDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbobxRWrkSkill
            // 
            this.cbobxRWrkSkill.FormattingEnabled = true;
            this.cbobxRWrkSkill.Location = new System.Drawing.Point(200, 217);
            this.cbobxRWrkSkill.Name = "cbobxRWrkSkill";
            this.cbobxRWrkSkill.Size = new System.Drawing.Size(121, 24);
            this.cbobxRWrkSkill.TabIndex = 2;
            // 
            // lblRWrkDocType
            // 
            this.lblRWrkDocType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRWrkDocType.Location = new System.Drawing.Point(20, 174);
            this.lblRWrkDocType.Name = "lblRWrkDocType";
            this.lblRWrkDocType.Size = new System.Drawing.Size(133, 25);
            this.lblRWrkDocType.TabIndex = 0;
            this.lblRWrkDocType.Text = "Document Type:";
            this.lblRWrkDocType.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbxRWrkDocType
            // 
            this.txtbxRWrkDocType.Location = new System.Drawing.Point(200, 174);
            this.txtbxRWrkDocType.Name = "txtbxRWrkDocType";
            this.txtbxRWrkDocType.ReadOnly = true;
            this.txtbxRWrkDocType.Size = new System.Drawing.Size(188, 22);
            this.txtbxRWrkDocType.TabIndex = 0;
            // 
            // frmResearchWork
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 379);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnBrowserFile);
            this.Controls.Add(this.btnSubmit);
            this.Name = "frmResearchWork";
            this.Text = "Research Work";
            this.Load += new System.EventHandler(this.frmResearchWork_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblRWrkId;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtbxRWrkDocName;
        private System.Windows.Forms.Label lblRWrkSkill;
        private System.Windows.Forms.TextBox txtbxRWrkId;
        private System.Windows.Forms.Label lblRWrkDocName;
        private System.Windows.Forms.Button btnBrowserFile;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.ComboBox cbobxRWrkSkill;
        private System.Windows.Forms.DateTimePicker dtpRWrkUpldDate;
        private System.Windows.Forms.Label lblRWrkUpldDate;
        private System.Windows.Forms.TextBox txtbxRWrkDocType;
        private System.Windows.Forms.Label lblRWrkDocType;
    }
}