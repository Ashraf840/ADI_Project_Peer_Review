﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    public partial class frmAuthor : Form
    {

        //This form is used to ******** add Authors (with skills) ********

        //Global Declaration Area

        //create an object of PeerReviewEntities(DB object) which is inside the
        //Model1.edmx -> Model1.Context.tt -> Model1.Context.cs
        PeerReviewEntities db = new PeerReviewEntities();

        public frmAuthor()
        {
            InitializeComponent();
        }

        private void frmAuthor_Load(object sender, EventArgs e)
        {
            //fecthes the UserName, user email address data & set their name to the text fields (authorName, authorEmail)
            txtbxAuthrName.Text = clsUserData.UserName;
            txtbxAuthrEmail.Text = clsUserData.UserEmail;

            //show all the skills stored inside the "Skill" table of the database
            //Select the "Skill" table's "Id" & "Name" field in particular, store that into the "data" variable
            var data = db.Skills.Select(d => new { d.Id, d.Name }).ToList();

            //the listbox "lstbxAuthrSkill" will get the data from "data"
            lstbxAuthrSkill.DataSource = data;
            //DisplayMember, the listbox "lstbxAuthrSkill" shows the value fetched from the "Skill" table.
            lstbxAuthrSkill.DisplayMember = "Name";
            //ValueMember, the listbox "lstbxAuthrSkill" returns the Id values of selected properties of the "Skill" table.
            lstbxAuthrSkill.ValueMember = "Id";
            //select option is set to Multiselection.
            lstbxAuthrSkill.SelectionMode = SelectionMode.MultiSimple;
            //disselect any property from the "lstbxAuthrSkill" listBox by default
            lstbxAuthrSkill.SelectedIndex = -1;
            //by default, disable the "btnSubmit" submit-button while the form loads 
            btnSubmit.Enabled = false;


            //if (data.Count == 0)
            //{
            //    MessageBox.Show("No skill found !!!");
            //    btnSubmit.Enabled = false;
            //}
            //else
            //{
            //    btnSubmit.Enabled = true;
            //}
        }

        private void lstbxAuthrSkill_Enter(object sender, EventArgs e)
        {
            btnSubmit.Enabled = true;
            btnSubmit.Cursor = Cursors.Hand;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                //find the specific author regarding his name in the author table, and store that inside a var datatype named "authrInfo"
                var authrInfo = db.Authors.Where(d => d.Name == txtbxAuthrName.Text).FirstOrDefault();

                //if the authortable doesn't contain that specific row of data, then insert the folowwing data to the author table's row (auhtor table doesn;t contain the specific data)
                if (authrInfo == null)
                {
                    //filling up that author information only inside the author table in DB (Author)
                    Author authr = new Author()
                    {
                        Name = txtbxAuthrName.Text,
                        Email = txtbxAuthrEmail.Text,
                        DOB = dtpAuthrDOB.Value,
                        usrId = clsUserData.UserId
                    };

                    db.Authors.Add(authr);
                    db.SaveChanges();

                    txtbxAuthrId.Text = authr.Id.ToString();

                    //filling up the skill names regarding individual authors ("AuthorSkill")
                    foreach (object item in lstbxAuthrSkill.SelectedItems)
                    {
                        //MessageBox.Show(item.ToString());
                        string idn = item.ToString().Split(',')[0].Substring(6);

                        AuthorSkill authrSkl = new AuthorSkill();
                        authrSkl.AuthrId = authr.Id;
                        authrSkl.SkillId = Int32.Parse(idn);

                        db.AuthorSkills.Add(authrSkl);
                        db.SaveChanges();
                    }
                    MessageBox.Show("Author & Skill Data Inserted successfully ....");
                }
                //but if the author table does contain that specific data, don't have to input data about that author, rather only input data regarding his skills
                else
                {
                    //if the user has a data-row inside "Author" table, then store that Id isnide the author id text-field
                    txtbxAuthrId.Text = authrInfo.Id.ToString();

                    //Author skill insert only
                    foreach (object item in lstbxAuthrSkill.SelectedItems)
                    {
                        //MessageBox.Show(item.ToString());
                        string idn = item.ToString().Split(',')[0].Substring(6);                        
                        int idNum = Int32.Parse(idn);

                        //find the specific data from "AuthorSkill" table regarding their authorId & skillId, and store that inside a var named "authrSkl"
                        var authrSkl = db.AuthorSkills.Where(d => d.AuthrId == authrInfo.Id && d.SkillId == idNum).FirstOrDefault();

                        //if the authorID coresponding skillId is null in the "AuthorSkill" table then insert the skill data regarding that author
                        if (authrSkl == null)
                        {
                            AuthorSkill authrSkill = new AuthorSkill();
                            authrSkill.AuthrId = authrInfo.Id;
                            authrSkill.SkillId = Int32.Parse(idn);

                            db.AuthorSkills.Add(authrSkill);
                            db.SaveChanges();

                            if (authrSkill.Id != 0)
                            {
                                MessageBox.Show("Only Skill Data Inserted Successfully....", "Successful", 
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        //but if the similar authorId coresponding its SkillId is already there, the system will not insert similar skillId 
                        else
                        {
                            MessageBox.Show("Similar Skills alreaady existed!", "Warning", 
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Data insert unsuccessful!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
