﻿namespace PeerReview_00163492
{
    partial class frmDownload
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblResearchId = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblDocName = new System.Windows.Forms.Label();
            this.lblDoc = new System.Windows.Forms.Label();
            this.txtbxId = new System.Windows.Forms.TextBox();
            this.txtbxDocName = new System.Windows.Forms.TextBox();
            this.cbobxDoc = new System.Windows.Forms.ComboBox();
            this.btnDownload = new System.Windows.Forms.Button();
            this.btnViewDocument = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblResearchId
            // 
            this.lblResearchId.AutoSize = true;
            this.lblResearchId.Location = new System.Drawing.Point(6, 50);
            this.lblResearchId.Name = "lblResearchId";
            this.lblResearchId.Size = new System.Drawing.Size(124, 17);
            this.lblResearchId.TabIndex = 0;
            this.lblResearchId.Text = "Type Research Id:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnViewDocument);
            this.groupBox1.Controls.Add(this.btnDownload);
            this.groupBox1.Controls.Add(this.cbobxDoc);
            this.groupBox1.Controls.Add(this.txtbxDocName);
            this.groupBox1.Controls.Add(this.txtbxId);
            this.groupBox1.Controls.Add(this.lblDoc);
            this.groupBox1.Controls.Add(this.lblDocName);
            this.groupBox1.Controls.Add(this.lblResearchId);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(428, 289);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Download Document";
            // 
            // lblDocName
            // 
            this.lblDocName.AutoSize = true;
            this.lblDocName.Location = new System.Drawing.Point(13, 100);
            this.lblDocName.Name = "lblDocName";
            this.lblDocName.Size = new System.Drawing.Size(117, 17);
            this.lblDocName.TabIndex = 0;
            this.lblDocName.Text = "Document Name:";
            // 
            // lblDoc
            // 
            this.lblDoc.AutoSize = true;
            this.lblDoc.Location = new System.Drawing.Point(54, 150);
            this.lblDoc.Name = "lblDoc";
            this.lblDoc.Size = new System.Drawing.Size(76, 17);
            this.lblDoc.TabIndex = 0;
            this.lblDoc.Text = "Document:";
            // 
            // txtbxId
            // 
            this.txtbxId.Location = new System.Drawing.Point(153, 50);
            this.txtbxId.Name = "txtbxId";
            this.txtbxId.Size = new System.Drawing.Size(100, 22);
            this.txtbxId.TabIndex = 1;
            // 
            // txtbxDocName
            // 
            this.txtbxDocName.Location = new System.Drawing.Point(153, 100);
            this.txtbxDocName.Name = "txtbxDocName";
            this.txtbxDocName.ReadOnly = true;
            this.txtbxDocName.Size = new System.Drawing.Size(269, 22);
            this.txtbxDocName.TabIndex = 1;
            // 
            // cbobxDoc
            // 
            this.cbobxDoc.FormattingEnabled = true;
            this.cbobxDoc.Location = new System.Drawing.Point(153, 150);
            this.cbobxDoc.Name = "cbobxDoc";
            this.cbobxDoc.Size = new System.Drawing.Size(207, 24);
            this.cbobxDoc.TabIndex = 2;
            this.cbobxDoc.SelectedIndexChanged += new System.EventHandler(this.cbobxDoc_SelectedIndexChanged);
            // 
            // btnDownload
            // 
            this.btnDownload.Location = new System.Drawing.Point(57, 229);
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.Size = new System.Drawing.Size(125, 34);
            this.btnDownload.TabIndex = 3;
            this.btnDownload.Text = "Download";
            this.btnDownload.UseVisualStyleBackColor = true;
            this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click);
            // 
            // btnViewDocument
            // 
            this.btnViewDocument.Location = new System.Drawing.Point(225, 229);
            this.btnViewDocument.Name = "btnViewDocument";
            this.btnViewDocument.Size = new System.Drawing.Size(135, 34);
            this.btnViewDocument.TabIndex = 3;
            this.btnViewDocument.Text = "View Document";
            this.btnViewDocument.UseVisualStyleBackColor = true;
            this.btnViewDocument.Click += new System.EventHandler(this.btnViewDocument_Click);
            // 
            // frmDownload
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(457, 318);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmDownload";
            this.Text = "Doc Download";
            this.Load += new System.EventHandler(this.frmDownload_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblResearchId;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnViewDocument;
        private System.Windows.Forms.Button btnDownload;
        private System.Windows.Forms.ComboBox cbobxDoc;
        private System.Windows.Forms.TextBox txtbxDocName;
        private System.Windows.Forms.TextBox txtbxId;
        private System.Windows.Forms.Label lblDoc;
        private System.Windows.Forms.Label lblDocName;
    }
}