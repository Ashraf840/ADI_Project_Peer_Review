﻿namespace PeerReview_00163492
{
    partial class frmConference
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label lblConferenceInfoId;
            System.Windows.Forms.Label lblConferenceTitle;
            System.Windows.Forms.Label lblConferenceStrtDate;
            System.Windows.Forms.Label lblProjDesc;
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtbxConferenceInfoId = new System.Windows.Forms.TextBox();
            this.txtbxConferenceTitle = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.dtpDateOfConference = new System.Windows.Forms.DateTimePicker();
            this.txtbxProjectDesc = new System.Windows.Forms.TextBox();
            lblConferenceInfoId = new System.Windows.Forms.Label();
            lblConferenceTitle = new System.Windows.Forms.Label();
            lblConferenceStrtDate = new System.Windows.Forms.Label();
            lblProjDesc = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dtpDateOfConference);
            this.groupBox1.Controls.Add(lblConferenceInfoId);
            this.groupBox1.Controls.Add(this.txtbxConferenceInfoId);
            this.groupBox1.Controls.Add(lblProjDesc);
            this.groupBox1.Controls.Add(lblConferenceTitle);
            this.groupBox1.Controls.Add(this.txtbxProjectDesc);
            this.groupBox1.Controls.Add(this.txtbxConferenceTitle);
            this.groupBox1.Controls.Add(lblConferenceStrtDate);
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(472, 286);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Conference Information";
            // 
            // lblConferenceInfoId
            // 
            lblConferenceInfoId.AutoSize = true;
            lblConferenceInfoId.Location = new System.Drawing.Point(6, 37);
            lblConferenceInfoId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblConferenceInfoId.Name = "lblConferenceInfoId";
            lblConferenceInfoId.Size = new System.Drawing.Size(127, 17);
            lblConferenceInfoId.TabIndex = 16;
            lblConferenceInfoId.Text = "Conference Info Id:";
            // 
            // txtbxConferenceInfoId
            // 
            this.txtbxConferenceInfoId.Location = new System.Drawing.Point(161, 34);
            this.txtbxConferenceInfoId.Margin = new System.Windows.Forms.Padding(4);
            this.txtbxConferenceInfoId.Name = "txtbxConferenceInfoId";
            this.txtbxConferenceInfoId.ReadOnly = true;
            this.txtbxConferenceInfoId.Size = new System.Drawing.Size(67, 22);
            this.txtbxConferenceInfoId.TabIndex = 17;
            // 
            // lblConferenceTitle
            // 
            lblConferenceTitle.AutoSize = true;
            lblConferenceTitle.Location = new System.Drawing.Point(13, 67);
            lblConferenceTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblConferenceTitle.Name = "lblConferenceTitle";
            lblConferenceTitle.Size = new System.Drawing.Size(120, 17);
            lblConferenceTitle.TabIndex = 18;
            lblConferenceTitle.Text = "Conference Title :";
            // 
            // txtbxConferenceTitle
            // 
            this.txtbxConferenceTitle.Location = new System.Drawing.Point(161, 64);
            this.txtbxConferenceTitle.Margin = new System.Windows.Forms.Padding(4);
            this.txtbxConferenceTitle.Name = "txtbxConferenceTitle";
            this.txtbxConferenceTitle.Size = new System.Drawing.Size(287, 22);
            this.txtbxConferenceTitle.TabIndex = 19;
            // 
            // lblConferenceStrtDate
            // 
            lblConferenceStrtDate.AutoSize = true;
            lblConferenceStrtDate.Location = new System.Drawing.Point(53, 250);
            lblConferenceStrtDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblConferenceStrtDate.Name = "lblConferenceStrtDate";
            lblConferenceStrtDate.Size = new System.Drawing.Size(80, 17);
            lblConferenceStrtDate.TabIndex = 22;
            lblConferenceStrtDate.Text = "Start Date :";
            // 
            // btnSubmit
            // 
            this.btnSubmit.ForeColor = System.Drawing.Color.Black;
            this.btnSubmit.Location = new System.Drawing.Point(13, 319);
            this.btnSubmit.Margin = new System.Windows.Forms.Padding(4);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(100, 26);
            this.btnSubmit.TabIndex = 34;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // dtpDateOfConference
            // 
            this.dtpDateOfConference.CustomFormat = "yyyy/MM/dd";
            this.dtpDateOfConference.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDateOfConference.Location = new System.Drawing.Point(161, 250);
            this.dtpDateOfConference.Name = "dtpDateOfConference";
            this.dtpDateOfConference.Size = new System.Drawing.Size(124, 22);
            this.dtpDateOfConference.TabIndex = 23;
            // 
            // txtbxProjectDesc
            // 
            this.txtbxProjectDesc.Location = new System.Drawing.Point(161, 105);
            this.txtbxProjectDesc.Margin = new System.Windows.Forms.Padding(4);
            this.txtbxProjectDesc.Multiline = true;
            this.txtbxProjectDesc.Name = "txtbxProjectDesc";
            this.txtbxProjectDesc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtbxProjectDesc.Size = new System.Drawing.Size(287, 124);
            this.txtbxProjectDesc.TabIndex = 19;
            // 
            // lblProjDesc
            // 
            lblProjDesc.AutoSize = true;
            lblProjDesc.Location = new System.Drawing.Point(50, 108);
            lblProjDesc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblProjDesc.Name = "lblProjDesc";
            lblProjDesc.Size = new System.Drawing.Size(83, 17);
            lblProjDesc.TabIndex = 18;
            lblProjDesc.Text = "Description:";
            // 
            // frmConference
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 358);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSubmit);
            this.Name = "frmConference";
            this.Text = "Create Conference";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtbxConferenceInfoId;
        private System.Windows.Forms.TextBox txtbxConferenceTitle;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.DateTimePicker dtpDateOfConference;
        private System.Windows.Forms.TextBox txtbxProjectDesc;
    }
}