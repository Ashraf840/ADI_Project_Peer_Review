﻿namespace PeerReview_00163492
{
    partial class frmRating
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label lblDoc;
            System.Windows.Forms.Label lblCmnt;
            System.Windows.Forms.Label lblRatingInfo;
            System.Windows.Forms.Label lblRatingValue;
            this.hScrollBarRating = new System.Windows.Forms.HScrollBar();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblRating = new System.Windows.Forms.Label();
            this.cbobxDoc = new System.Windows.Forms.ComboBox();
            this.cbobxCmnt = new System.Windows.Forms.ComboBox();
            this.txtbxRatingInfoId = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            lblDoc = new System.Windows.Forms.Label();
            lblCmnt = new System.Windows.Forms.Label();
            lblRatingInfo = new System.Windows.Forms.Label();
            lblRatingValue = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblDoc
            // 
            lblDoc.AutoSize = true;
            lblDoc.Location = new System.Drawing.Point(26, 163);
            lblDoc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblDoc.Name = "lblDoc";
            lblDoc.Size = new System.Drawing.Size(80, 17);
            lblDoc.TabIndex = 31;
            lblDoc.Text = "Document :";
            // 
            // lblCmnt
            // 
            lblCmnt.AutoSize = true;
            lblCmnt.Location = new System.Drawing.Point(34, 127);
            lblCmnt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblCmnt.Name = "lblCmnt";
            lblCmnt.Size = new System.Drawing.Size(75, 17);
            lblCmnt.TabIndex = 24;
            lblCmnt.Text = "Comment :";
            // 
            // lblRatingInfo
            // 
            lblRatingInfo.AutoSize = true;
            lblRatingInfo.Location = new System.Drawing.Point(14, 41);
            lblRatingInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblRatingInfo.Name = "lblRatingInfo";
            lblRatingInfo.Size = new System.Drawing.Size(95, 17);
            lblRatingInfo.TabIndex = 16;
            lblRatingInfo.Text = "Rating Info Id:";
            // 
            // hScrollBarRating
            // 
            this.hScrollBarRating.LargeChange = 2;
            this.hScrollBarRating.Location = new System.Drawing.Point(197, 80);
            this.hScrollBarRating.Maximum = 11;
            this.hScrollBarRating.Name = "hScrollBarRating";
            this.hScrollBarRating.Size = new System.Drawing.Size(161, 17);
            this.hScrollBarRating.TabIndex = 0;
            this.hScrollBarRating.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBarRating_Scroll);
            // 
            // lblRatingValue
            // 
            lblRatingValue.AutoSize = true;
            lblRatingValue.Location = new System.Drawing.Point(14, 80);
            lblRatingValue.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblRatingValue.Name = "lblRatingValue";
            lblRatingValue.Size = new System.Drawing.Size(97, 17);
            lblRatingValue.TabIndex = 18;
            lblRatingValue.Text = "Rating Value :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblRating);
            this.groupBox1.Controls.Add(this.cbobxDoc);
            this.groupBox1.Controls.Add(lblDoc);
            this.groupBox1.Controls.Add(this.cbobxCmnt);
            this.groupBox1.Controls.Add(lblCmnt);
            this.groupBox1.Controls.Add(lblRatingInfo);
            this.groupBox1.Controls.Add(this.txtbxRatingInfoId);
            this.groupBox1.Controls.Add(this.hScrollBarRating);
            this.groupBox1.Controls.Add(lblRatingValue);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(512, 217);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Rating Information";
            // 
            // lblRating
            // 
            this.lblRating.AutoSize = true;
            this.lblRating.Location = new System.Drawing.Point(405, 80);
            this.lblRating.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRating.Name = "lblRating";
            this.lblRating.Size = new System.Drawing.Size(16, 17);
            this.lblRating.TabIndex = 33;
            this.lblRating.Text = "0";
            // 
            // cbobxDoc
            // 
            this.cbobxDoc.FormattingEnabled = true;
            this.cbobxDoc.Location = new System.Drawing.Point(197, 156);
            this.cbobxDoc.Margin = new System.Windows.Forms.Padding(4);
            this.cbobxDoc.Name = "cbobxDoc";
            this.cbobxDoc.Size = new System.Drawing.Size(203, 24);
            this.cbobxDoc.TabIndex = 32;
            // 
            // cbobxCmnt
            // 
            this.cbobxCmnt.FormattingEnabled = true;
            this.cbobxCmnt.Location = new System.Drawing.Point(197, 120);
            this.cbobxCmnt.Margin = new System.Windows.Forms.Padding(4);
            this.cbobxCmnt.Name = "cbobxCmnt";
            this.cbobxCmnt.Size = new System.Drawing.Size(203, 24);
            this.cbobxCmnt.TabIndex = 30;
            // 
            // txtbxRatingInfoId
            // 
            this.txtbxRatingInfoId.Location = new System.Drawing.Point(197, 38);
            this.txtbxRatingInfoId.Margin = new System.Windows.Forms.Padding(4);
            this.txtbxRatingInfoId.Name = "txtbxRatingInfoId";
            this.txtbxRatingInfoId.ReadOnly = true;
            this.txtbxRatingInfoId.Size = new System.Drawing.Size(67, 22);
            this.txtbxRatingInfoId.TabIndex = 17;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(19, 261);
            this.btnSubmit.Margin = new System.Windows.Forms.Padding(4);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(100, 30);
            this.btnSubmit.TabIndex = 34;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(152, 261);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 30);
            this.btnClose.TabIndex = 34;
            this.btnClose.Text = "&Cancel";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmRating
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 320);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSubmit);
            this.Name = "frmRating";
            this.Text = "Rating";
            this.Load += new System.EventHandler(this.frmRating_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.HScrollBar hScrollBarRating;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblRating;
        private System.Windows.Forms.ComboBox cbobxDoc;
        private System.Windows.Forms.ComboBox cbobxCmnt;
        private System.Windows.Forms.TextBox txtbxRatingInfoId;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnClose;
    }
}