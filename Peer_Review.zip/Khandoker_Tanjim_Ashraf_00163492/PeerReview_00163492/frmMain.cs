﻿using PeerReview_00163492.List;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            //if the user is not an admin, then he/she might be an author or a reviewer
            if (clsUserData.RoleName.ToLower() != "Admin".ToLower())
            {
                skillToolStripMenuItem.Visible = false;
                userRoleToolStripMenuItem.Visible = false;
            }

            //if the user is not an author, then he/she might be an admin or a reviewer
            if (clsUserData.RoleName.ToLower() != "Author".ToLower())
            {
                authorToolStripMenuItem.Visible = false;
                uploadDocumentToolStripMenuItem.Visible = false;
                ratingToolStripMenuItem.Visible = false;
                //even if the user is not an admin as well, then the user must be a reviewer
                if (clsUserData.RoleName.ToLower() != "Admin".ToLower())
                {
                    //an reviewer cannot see "author information"
                    authorInformationToolStripMenuItem.Visible = false;
                }
            }

            //if the user is not a reviewer, then he/she might be an admin or an author
            if (clsUserData.RoleName.ToLower() != "Reviewer".ToLower())
            {
                reviewerToolStripMenuItem.Visible = false;       //Admins & Authors are not allowed to enter "frmReviewer" form to set a reviewer's skills
                commentToolStripMenuItem.Visible = false;        //Admins & Authors are not allowed to Comment
                downloadDocumentToolStripMenuItem.Visible = false;      //Admins & Authors are not allowed to Download Documents
                //even if the user is not an admin as well, then the user must be an author
                if (clsUserData.RoleName.ToLower() != "Admin".ToLower())
                {
                    //an author cannot see "reviewer information"
                    reviewerToolStripMenuItem1.Visible = false;
                }
            }

            //displays a welcome msg including the userName, and userId
            toolStripStatusLabel1.Text = string.Format("Welcome {0} [{1}], [UserId: {2}]",
                                                        clsUserData.UserName, clsUserData.RoleName, clsUserData.UserId);
        }


        //********************* M E N U  -  S T R I P  codes starts here *********************

        //MENU: APP :Decending-buttons codes
        //"Logout" btn code
        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmLogin fLogin = new frmLogin();
            fLogin.Show();
        }
        //"Exit" btn code
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        //MENU: FILE :Decending-buttons codes    ***************
        //"Register User" information insert form, to display the "frmAccount" aka User Registration form
        private void registerUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAccount fmAccnt = new frmAccount();
            fmAccnt.Show();
        }
        //"Skill" information insert form, to display the "frmSkill" aka User Skill-list entry form
        private void skillToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSkill fmSkill = new frmSkill();
            fmSkill.Show();
        }
        //"Author" information insert form, to display the "frmAuthor" aka Authors entry form
        private void authorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAuthor fmAuthr = new frmAuthor();
            fmAuthr.Show();
        }
        //Displays the conference creation entry form "frmConference"
        private void conferenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConference fmConfInfo = new frmConference();
            fmConfInfo.Show();
        }        
        //"Upload Document" form show
        private void uploadDocumentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmResearchWork fmRsrchWrk = new frmResearchWork();
            fmRsrchWrk.Show();
        }
        //"Reviewer" information insert form, to display the "frmReviewer" aka Reviewers entry form
        private void reviewerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReviewer fmRev = new frmReviewer();
            fmRev.Show();
        }
        //"Peer Review" information insert form, to display the "frmPeerReview" aka Peer Reviewing process entry form
        private void peerReviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPeerReview fmPReview = new frmPeerReview();
            fmPReview.Show();
        }
        //Displays the comments made by the reviewers entry form "frmComment"
        private void commentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmComment fmCmnt = new frmComment();
            fmCmnt.Show();
        }
        //"frmRating", displays rating form since the authors can make ratings of each reviewers comment on their research paper
        private void ratingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRating fmRating = new frmRating();
            fmRating.Show();
        }
        //"Download Document" form to download research work documents.
        private void downloadDocumentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDownload fmDownload = new frmDownload();
            fmDownload.Show();
        }
        //"User Role" information insert form btn code to display the "frmUserRole"
        private void userRoleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUserRole frmUsrRole = new frmUserRole();
            frmUsrRole.Show();
        }


        //MENU: LIST :Decending-buttons codes    ***************
        //Displays a form consisted of all the information of an individual author, or the entire authors (if logged in as an admin)
        private void authorInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAuthorList fAuthrLst = new frmAuthorList();
            fAuthrLst.Show();
        }
        //Displays a form consisted of all the information of an individual reviewer, or the entire reviewers (if logged in as an admin)
        private void reviewerToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmReviewerList fReviewr = new frmReviewerList();
            fReviewr.Show();
        }
        //Displays a form consisted of all the stored skills inserted into the system
        private void skillInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSkillList fSkillLst = new frmSkillList();
            fSkillLst.Show();
        }
        //Displays a form consisted of all the research work papers inserted into the system
        private void researchWorkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmResearchWorkList fResrchWrk = new frmResearchWorkList();
            fResrchWrk.Show();
        }
        //Displays a form consisted of all the registered users list with some specific information
        private void userInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAccountList fAccountList = new frmAccountList();
            fAccountList.Show();
        }
        //Displays a form consisted of all the catagories of user roles listed inside a database
        private void userRoleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmUserRoleList fURLst = new frmUserRoleList();
            fURLst.Show();
        }
        //Displays the list of all assigned/unassigned reviewers to Research Work naming "frmResearchWorkList"
        private void reviewerResearchWorkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAssignedResearchWorkList fAssgnRWLst = new frmAssignedResearchWorkList();
            fAssgnRWLst.Show();
        }
        //Displays the list of created all conferences naming "frmConferenceInfoList"
        private void conferenceToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmConferenceInfoList fConfInfoLst = new frmConferenceInfoList();
            fConfInfoLst.Show();
        }

        //MENU: SEARCH :Decending-buttons codes    ***************
        //"frmSearchList", displays the form of Search Comment List
        private void searchByWordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSearchList fSrchLst = new frmSearchList();
            fSrchLst.Show();
        }
    }
}
