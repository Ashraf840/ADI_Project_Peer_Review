﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    //user-role data insert form
    public partial class frmUserRole : Form
    {
        //Global Declaration Area

        //create an object of PeerReviewEntities which is inside the
        //Model1.edmx -> Model1.Context.tt -> Model1.Context.cs
        PeerReviewEntities db = new PeerReviewEntities();


        public frmUserRole()
        {
            InitializeComponent();
        }

        private void frmUserRole_Load(object sender, EventArgs e)
        {
            /*
             ************** Make the ID textBox automatically set the next value of the **************
             * ******************** record immediately after this form is opened ******************* *
             */
            /*
            UserRole usrRole = new UserRole();
            int nxtID = usrRole.Id;

            txtbxId.Text = nxtID.ToString();
            */
        }

        //insert user role data
        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                //instantiate an object of "UserRole" class which is inside the 
                //Model1.edmx -> Model1.tt -> UserRole.cs
                UserRole usrRole = new UserRole();
                //assign the value from user textBox to field of "Name" inside the "usrRole"
                usrRole.Name = txtbxName.Text;

                //******************** validation for empty textBox and repeat value ********************
                //validate if the "Name" textBox is not empty.
                if (usrRole.Name != "")
                {
                    //******************** validation for repeat value (similar NAME) ********************

                    //                (  N O T   C O M P L E T E D  )

                    //******************** END ********************

                    //add the entire "usrRole" object to the PeerReviewEntities object naming "db"
                    db.UserRoles.Add(usrRole);

                    //to make all the changes, the "db" object, it is needed to call the "SaveChanges()" method.
                    //It saves all the changes to the underlying databases which are made in the current context("usrRole").
                    db.SaveChanges();

                    //validation for whether the data is actually inserted into the database. 
                    //Cz even if the first data gets inserted, the index of Id will be programatically starts from "1".
                    if (usrRole.Id != 0)
                    {
                        //the Id textBox (read-only) is assigned to the next Id number which is fetched from the database
                        txtbxId.Text = usrRole.Id.ToString();
                        MessageBox.Show("Data Inserted Successfully!", "Insert",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Data already exists !", "Warning",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Name field is empty!!", "Warning",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                //******************** Ends here ********************

            }
            catch (Exception)
            {
                MessageBox.Show("Data insert unsuccessful!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }
        
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}
