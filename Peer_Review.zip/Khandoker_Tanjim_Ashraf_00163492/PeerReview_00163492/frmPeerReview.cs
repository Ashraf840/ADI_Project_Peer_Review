﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    public partial class frmPeerReview : Form
    {

        PeerReviewEntities db = new PeerReviewEntities();

        public frmPeerReview()
        {
            InitializeComponent();
        }

        private void frmPeerReview_Load(object sender, EventArgs e)
        {
            RefreshData();

            //var data = db.ResearchWorks.Select(d => new { d.Doc, d.Skill.Id }).ToList();

            //cbobxDocId.DataSource = data;   //the data table which contains the particular data
            //cbobxDocId.DisplayMember = "Doc";   // column name that you need to display as text
            //cbobxDocId.ValueMember = "Id";  // column name which you want in SelectedValue [ which is in this case, specific skillIds regarding that particular Doc ]
        }

#pragma warning disable CS0114 // Member hides inherited member; missing override keyword
        private void RefreshData()
#pragma warning restore CS0114 // Member hides inherited member; missing override keyword
        {
            //displays Doc name in the comboBox naming "cbobxDocId"
            //get skillId through d.Skill.Id from the comboBox of "cbobxDocId" from ResearchWork table of the DB
            var data = db.ResearchWorks.Select(d => new { d.Doc, d.Skill.Id, d.isReviewer }).ToList();

            cbobxDocId.DataSource = null;
            cbobxDocId.DataSource = data;   //the data table which contains the particular data
            cbobxDocId.DisplayMember = "Doc";   // column name that you need to display as text
            cbobxDocId.ValueMember = "Id";  // column name which you want in SelectedValue [ wchi is in this case, specific skillIds regarding that particular Doc ]
        }

        private void cbobxDocId_SelectionChangeCommitted(object sender, EventArgs e)
        {
            //displays the Reviewers list inside the comboBox naming "cbobxReviewerId" 
            //when a particular Doc which consists of a specific skill is seleted, 
            //afterward the drop-down list is closed.
            int rskillId = Int32.Parse(cbobxDocId.SelectedValue.ToString());

            //displays the list of reviewers based on the selected Doc's skill
            var rData = db.ReviewerSkills.Select(d => new { d.reviewerId, d.skillId, ReviewerName = d.Reviewer.Name }).Where(d => d.reviewerId == rskillId).ToList();

            cbobxReviewerId.DataSource = rData;
            cbobxReviewerId.DisplayMember = "ReviewerName";
            cbobxReviewerId.ValueMember = "reviewerId";
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //-------------------Peer Review Data DB Insert-------------------
            PeerReview PR = new PeerReview();

            PR.DOR = dtpPRDOR.Value;
            PR.docId = Int32.Parse(cbobxDocId.SelectedValue.ToString());
            PR.reviewerId = Int32.Parse(cbobxReviewerId.SelectedValue.ToString());
            PR.isComment = false;     //by default, comment is set to false in the beginning

            db.PeerReviews.Add(PR);
            db.SaveChanges();

            txtbxPRId.Text = PR.Id.ToString();

            //Modify research work
            var modRW = db.ResearchWorks.Where(d => d.Doc == cbobxDocId.Text).FirstOrDefault();
            modRW.isReviewer = true;     //reviewer has assigned on that specific research paper
            db.SaveChanges();

            RefreshData();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
