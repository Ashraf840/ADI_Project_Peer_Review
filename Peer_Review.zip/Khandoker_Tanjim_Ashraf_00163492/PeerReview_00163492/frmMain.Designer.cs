﻿namespace PeerReview_00163492
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.appToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registerUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.skillToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.authorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conferenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uploadDocumentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reviewerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.peerReviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.commentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ratingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.downloadDocumentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userRoleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.authorInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reviewerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.skillInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.researchWorkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.commentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ratingToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.userInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userRoleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.conferenceToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reviewerResearchWorkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchByWordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.appToolStripMenuItem,
            this.fileToolStripMenuItem,
            this.listToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // appToolStripMenuItem
            // 
            this.appToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logOutToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.appToolStripMenuItem.Name = "appToolStripMenuItem";
            this.appToolStripMenuItem.Size = new System.Drawing.Size(49, 24);
            this.appToolStripMenuItem.Text = "&App";
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.logOutToolStripMenuItem.Text = "Log Out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(158, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registerUserToolStripMenuItem,
            this.skillToolStripMenuItem,
            this.authorToolStripMenuItem,
            this.conferenceToolStripMenuItem,
            this.uploadDocumentToolStripMenuItem,
            this.reviewerToolStripMenuItem,
            this.peerReviewToolStripMenuItem,
            this.commentToolStripMenuItem,
            this.ratingToolStripMenuItem,
            this.downloadDocumentToolStripMenuItem,
            this.userRoleToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // registerUserToolStripMenuItem
            // 
            this.registerUserToolStripMenuItem.Name = "registerUserToolStripMenuItem";
            this.registerUserToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.registerUserToolStripMenuItem.Text = "Register User";
            this.registerUserToolStripMenuItem.Click += new System.EventHandler(this.registerUserToolStripMenuItem_Click);
            // 
            // skillToolStripMenuItem
            // 
            this.skillToolStripMenuItem.Name = "skillToolStripMenuItem";
            this.skillToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.skillToolStripMenuItem.Text = "Skill";
            this.skillToolStripMenuItem.Click += new System.EventHandler(this.skillToolStripMenuItem_Click);
            // 
            // authorToolStripMenuItem
            // 
            this.authorToolStripMenuItem.Name = "authorToolStripMenuItem";
            this.authorToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.authorToolStripMenuItem.Text = "Author";
            this.authorToolStripMenuItem.Click += new System.EventHandler(this.authorToolStripMenuItem_Click);
            // 
            // conferenceToolStripMenuItem
            // 
            this.conferenceToolStripMenuItem.Name = "conferenceToolStripMenuItem";
            this.conferenceToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.conferenceToolStripMenuItem.Text = "Conference";
            this.conferenceToolStripMenuItem.Click += new System.EventHandler(this.conferenceToolStripMenuItem_Click);
            // 
            // uploadDocumentToolStripMenuItem
            // 
            this.uploadDocumentToolStripMenuItem.Name = "uploadDocumentToolStripMenuItem";
            this.uploadDocumentToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.uploadDocumentToolStripMenuItem.Text = "Upload Document";
            this.uploadDocumentToolStripMenuItem.Click += new System.EventHandler(this.uploadDocumentToolStripMenuItem_Click);
            // 
            // reviewerToolStripMenuItem
            // 
            this.reviewerToolStripMenuItem.Name = "reviewerToolStripMenuItem";
            this.reviewerToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.reviewerToolStripMenuItem.Text = "Reviewer";
            this.reviewerToolStripMenuItem.Click += new System.EventHandler(this.reviewerToolStripMenuItem_Click);
            // 
            // peerReviewToolStripMenuItem
            // 
            this.peerReviewToolStripMenuItem.Name = "peerReviewToolStripMenuItem";
            this.peerReviewToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.peerReviewToolStripMenuItem.Text = "Peer Review";
            this.peerReviewToolStripMenuItem.Click += new System.EventHandler(this.peerReviewToolStripMenuItem_Click);
            // 
            // commentToolStripMenuItem
            // 
            this.commentToolStripMenuItem.Name = "commentToolStripMenuItem";
            this.commentToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.commentToolStripMenuItem.Text = "Comment";
            this.commentToolStripMenuItem.Click += new System.EventHandler(this.commentToolStripMenuItem_Click);
            // 
            // ratingToolStripMenuItem
            // 
            this.ratingToolStripMenuItem.Name = "ratingToolStripMenuItem";
            this.ratingToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.ratingToolStripMenuItem.Text = "Rating";
            this.ratingToolStripMenuItem.Click += new System.EventHandler(this.ratingToolStripMenuItem_Click);
            // 
            // downloadDocumentToolStripMenuItem
            // 
            this.downloadDocumentToolStripMenuItem.Name = "downloadDocumentToolStripMenuItem";
            this.downloadDocumentToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.downloadDocumentToolStripMenuItem.Text = "Download Document";
            this.downloadDocumentToolStripMenuItem.Click += new System.EventHandler(this.downloadDocumentToolStripMenuItem_Click);
            // 
            // userRoleToolStripMenuItem
            // 
            this.userRoleToolStripMenuItem.Name = "userRoleToolStripMenuItem";
            this.userRoleToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.userRoleToolStripMenuItem.Text = "User Role";
            this.userRoleToolStripMenuItem.Click += new System.EventHandler(this.userRoleToolStripMenuItem_Click);
            // 
            // listToolStripMenuItem
            // 
            this.listToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.authorInformationToolStripMenuItem,
            this.reviewerToolStripMenuItem1,
            this.skillInformationToolStripMenuItem,
            this.researchWorkToolStripMenuItem,
            this.commentToolStripMenuItem1,
            this.ratingToolStripMenuItem1,
            this.userInformationToolStripMenuItem,
            this.userRoleToolStripMenuItem1,
            this.conferenceToolStripMenuItem1,
            this.reviewerResearchWorkToolStripMenuItem});
            this.listToolStripMenuItem.Name = "listToolStripMenuItem";
            this.listToolStripMenuItem.Size = new System.Drawing.Size(43, 24);
            this.listToolStripMenuItem.Text = "&List";
            // 
            // authorInformationToolStripMenuItem
            // 
            this.authorInformationToolStripMenuItem.Name = "authorInformationToolStripMenuItem";
            this.authorInformationToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.authorInformationToolStripMenuItem.Text = "Author Information";
            this.authorInformationToolStripMenuItem.Click += new System.EventHandler(this.authorInformationToolStripMenuItem_Click);
            // 
            // reviewerToolStripMenuItem1
            // 
            this.reviewerToolStripMenuItem1.Name = "reviewerToolStripMenuItem1";
            this.reviewerToolStripMenuItem1.Size = new System.Drawing.Size(245, 26);
            this.reviewerToolStripMenuItem1.Text = "Reviewer Information";
            this.reviewerToolStripMenuItem1.Click += new System.EventHandler(this.reviewerToolStripMenuItem1_Click);
            // 
            // skillInformationToolStripMenuItem
            // 
            this.skillInformationToolStripMenuItem.Name = "skillInformationToolStripMenuItem";
            this.skillInformationToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.skillInformationToolStripMenuItem.Text = "All Skill Information";
            this.skillInformationToolStripMenuItem.Click += new System.EventHandler(this.skillInformationToolStripMenuItem_Click);
            // 
            // researchWorkToolStripMenuItem
            // 
            this.researchWorkToolStripMenuItem.Name = "researchWorkToolStripMenuItem";
            this.researchWorkToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.researchWorkToolStripMenuItem.Text = "Research Work";
            this.researchWorkToolStripMenuItem.Click += new System.EventHandler(this.researchWorkToolStripMenuItem_Click);
            // 
            // commentToolStripMenuItem1
            // 
            this.commentToolStripMenuItem1.Name = "commentToolStripMenuItem1";
            this.commentToolStripMenuItem1.Size = new System.Drawing.Size(245, 26);
            this.commentToolStripMenuItem1.Text = "Comment";
            // 
            // ratingToolStripMenuItem1
            // 
            this.ratingToolStripMenuItem1.Name = "ratingToolStripMenuItem1";
            this.ratingToolStripMenuItem1.Size = new System.Drawing.Size(245, 26);
            this.ratingToolStripMenuItem1.Text = "Rating";
            // 
            // userInformationToolStripMenuItem
            // 
            this.userInformationToolStripMenuItem.Name = "userInformationToolStripMenuItem";
            this.userInformationToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.userInformationToolStripMenuItem.Text = "All User Information";
            this.userInformationToolStripMenuItem.Click += new System.EventHandler(this.userInformationToolStripMenuItem_Click);
            // 
            // userRoleToolStripMenuItem1
            // 
            this.userRoleToolStripMenuItem1.Name = "userRoleToolStripMenuItem1";
            this.userRoleToolStripMenuItem1.Size = new System.Drawing.Size(245, 26);
            this.userRoleToolStripMenuItem1.Text = "All Role Information";
            this.userRoleToolStripMenuItem1.Click += new System.EventHandler(this.userRoleToolStripMenuItem1_Click);
            // 
            // conferenceToolStripMenuItem1
            // 
            this.conferenceToolStripMenuItem1.Name = "conferenceToolStripMenuItem1";
            this.conferenceToolStripMenuItem1.Size = new System.Drawing.Size(245, 26);
            this.conferenceToolStripMenuItem1.Text = "Conference";
            this.conferenceToolStripMenuItem1.Click += new System.EventHandler(this.conferenceToolStripMenuItem1_Click);
            // 
            // reviewerResearchWorkToolStripMenuItem
            // 
            this.reviewerResearchWorkToolStripMenuItem.Name = "reviewerResearchWorkToolStripMenuItem";
            this.reviewerResearchWorkToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.reviewerResearchWorkToolStripMenuItem.Text = "Reviewer Research Work";
            this.reviewerResearchWorkToolStripMenuItem.Click += new System.EventHandler(this.reviewerResearchWorkToolStripMenuItem_Click);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.searchByWordToolStripMenuItem});
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.searchToolStripMenuItem.Text = "&Search";
            // 
            // searchByWordToolStripMenuItem
            // 
            this.searchByWordToolStripMenuItem.Name = "searchByWordToolStripMenuItem";
            this.searchByWordToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.searchByWordToolStripMenuItem.Text = "Search By Word";
            this.searchByWordToolStripMenuItem.Click += new System.EventHandler(this.searchByWordToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(149, 26);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 425);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(800, 25);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(190, 20);
            this.toolStripStatusLabel1.Text = "Welcome, X. UserRolename";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "Peer Review";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem appToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registerUserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem skillToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem authorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conferenceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uploadDocumentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reviewerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem peerReviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem commentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ratingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem downloadDocumentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem authorInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem skillInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem researchWorkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem commentToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reviewerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ratingToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem userInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conferenceToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem searchByWordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userRoleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userRoleToolStripMenuItem1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem reviewerResearchWorkToolStripMenuItem;
    }
}

