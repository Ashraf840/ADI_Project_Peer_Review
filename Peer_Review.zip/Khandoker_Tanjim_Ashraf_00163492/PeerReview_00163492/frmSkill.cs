﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    public partial class frmSkill : Form
    {
        //Global Declaration Area

        //create an object of PeerReviewEntities(DB object) which is inside the
        //Model1.edmx -> Model1.Context.tt -> Model1.Context.cs
        PeerReviewEntities db = new PeerReviewEntities();

        public frmSkill()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Skill skl = new Skill();

                skl.Name = txtbxSkillName.Text;
                skl.Description = txtbxSkillDesc.Text;

                //******************** validation for empty textBox only  ********************
                //validate if the "Name" textBox is not empty. (Desc. field is exempted from this validation)
                if (skl.Name != "")
                {
                    db.Skills.Add(skl);
                    db.SaveChanges();

                    //validation for whether the data is actually inserted into the database. 
                    //Cz even if the first data gets inserted, the index of Id will be programatically starts from "1".
                    if (skl.Id != 0)
                    {
                        txtbxSkillId.Text = skl.Id.ToString();
                        MessageBox.Show("Data Inserted Successfully!", "Insert",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Data already exists !", "Warning",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Name field is empty!!", "Warning",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                //******************** Ends here ********************

            }
            catch (Exception)
            {
                MessageBox.Show("Data insert unsuccessful!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
