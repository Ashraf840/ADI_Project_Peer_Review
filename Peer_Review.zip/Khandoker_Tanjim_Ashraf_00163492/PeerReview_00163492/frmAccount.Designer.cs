﻿namespace PeerReview_00163492
{
    partial class frmAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.txtbxUsrName = new System.Windows.Forms.TextBox();
            this.txtbxUsrId = new System.Windows.Forms.TextBox();
            this.lblUsrName = new System.Windows.Forms.Label();
            this.lblUsrId = new System.Windows.Forms.Label();
            this.lblUsrEmailAddrss = new System.Windows.Forms.Label();
            this.txtbxUsrEmail = new System.Windows.Forms.TextBox();
            this.lblUsrPass = new System.Windows.Forms.Label();
            this.txtbxUsrPass = new System.Windows.Forms.TextBox();
            this.lblUsrType = new System.Windows.Forms.Label();
            this.cbobxUsrType = new System.Windows.Forms.ComboBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbobxUsrType);
            this.groupBox1.Controls.Add(this.txtbxUsrPass);
            this.groupBox1.Controls.Add(this.lblUsrType);
            this.groupBox1.Controls.Add(this.txtbxUsrEmail);
            this.groupBox1.Controls.Add(this.lblUsrPass);
            this.groupBox1.Controls.Add(this.txtbxUsrName);
            this.groupBox1.Controls.Add(this.lblUsrEmailAddrss);
            this.groupBox1.Controls.Add(this.txtbxUsrId);
            this.groupBox1.Controls.Add(this.lblUsrName);
            this.groupBox1.Controls.Add(this.lblUsrId);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(468, 264);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "User Account Information";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(12, 282);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(83, 34);
            this.btnSubmit.TabIndex = 5;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // txtbxUsrName
            // 
            this.txtbxUsrName.Location = new System.Drawing.Point(156, 91);
            this.txtbxUsrName.Name = "txtbxUsrName";
            this.txtbxUsrName.Size = new System.Drawing.Size(233, 22);
            this.txtbxUsrName.TabIndex = 1;
            // 
            // txtbxUsrId
            // 
            this.txtbxUsrId.Location = new System.Drawing.Point(156, 50);
            this.txtbxUsrId.Name = "txtbxUsrId";
            this.txtbxUsrId.ReadOnly = true;
            this.txtbxUsrId.Size = new System.Drawing.Size(100, 22);
            this.txtbxUsrId.TabIndex = 7;
            // 
            // lblUsrName
            // 
            this.lblUsrName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUsrName.Location = new System.Drawing.Point(20, 90);
            this.lblUsrName.Name = "lblUsrName";
            this.lblUsrName.Size = new System.Drawing.Size(119, 25);
            this.lblUsrName.TabIndex = 0;
            this.lblUsrName.Text = "User Name:";
            this.lblUsrName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUsrId
            // 
            this.lblUsrId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUsrId.Location = new System.Drawing.Point(20, 50);
            this.lblUsrId.Name = "lblUsrId";
            this.lblUsrId.Size = new System.Drawing.Size(119, 25);
            this.lblUsrId.TabIndex = 0;
            this.lblUsrId.Text = "User Id:";
            this.lblUsrId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUsrEmailAddrss
            // 
            this.lblUsrEmailAddrss.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUsrEmailAddrss.Location = new System.Drawing.Point(20, 130);
            this.lblUsrEmailAddrss.Name = "lblUsrEmailAddrss";
            this.lblUsrEmailAddrss.Size = new System.Drawing.Size(119, 25);
            this.lblUsrEmailAddrss.TabIndex = 0;
            this.lblUsrEmailAddrss.Text = "Email Address:";
            this.lblUsrEmailAddrss.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbxUsrEmail
            // 
            this.txtbxUsrEmail.Location = new System.Drawing.Point(156, 130);
            this.txtbxUsrEmail.Name = "txtbxUsrEmail";
            this.txtbxUsrEmail.Size = new System.Drawing.Size(233, 22);
            this.txtbxUsrEmail.TabIndex = 2;
            // 
            // lblUsrPass
            // 
            this.lblUsrPass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUsrPass.Location = new System.Drawing.Point(20, 170);
            this.lblUsrPass.Name = "lblUsrPass";
            this.lblUsrPass.Size = new System.Drawing.Size(119, 25);
            this.lblUsrPass.TabIndex = 0;
            this.lblUsrPass.Text = "Password:";
            this.lblUsrPass.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbxUsrPass
            // 
            this.txtbxUsrPass.Location = new System.Drawing.Point(156, 170);
            this.txtbxUsrPass.Name = "txtbxUsrPass";
            this.txtbxUsrPass.Size = new System.Drawing.Size(233, 22);
            this.txtbxUsrPass.TabIndex = 3;
            // 
            // lblUsrType
            // 
            this.lblUsrType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUsrType.Location = new System.Drawing.Point(20, 210);
            this.lblUsrType.Name = "lblUsrType";
            this.lblUsrType.Size = new System.Drawing.Size(119, 25);
            this.lblUsrType.TabIndex = 0;
            this.lblUsrType.Text = "User Type:";
            this.lblUsrType.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbobxUsrType
            // 
            this.cbobxUsrType.FormattingEnabled = true;
            this.cbobxUsrType.Location = new System.Drawing.Point(156, 210);
            this.cbobxUsrType.Name = "cbobxUsrType";
            this.cbobxUsrType.Size = new System.Drawing.Size(233, 24);
            this.cbobxUsrType.TabIndex = 4;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(101, 282);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(83, 34);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "&Cancel";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 330);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSubmit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAccount";
            this.Text = "User Registration";
            this.Load += new System.EventHandler(this.frmAccount_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.TextBox txtbxUsrName;
        private System.Windows.Forms.TextBox txtbxUsrId;
        private System.Windows.Forms.Label lblUsrName;
        private System.Windows.Forms.Label lblUsrId;
        private System.Windows.Forms.ComboBox cbobxUsrType;
        private System.Windows.Forms.TextBox txtbxUsrPass;
        private System.Windows.Forms.Label lblUsrType;
        private System.Windows.Forms.TextBox txtbxUsrEmail;
        private System.Windows.Forms.Label lblUsrPass;
        private System.Windows.Forms.Label lblUsrEmailAddrss;
        private System.Windows.Forms.Button btnClose;
    }
}