﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    public partial class frmRating : Form
    {

        PeerReviewEntities db = new PeerReviewEntities();

        public frmRating()
        {
            InitializeComponent();
        }

        private void frmRating_Load(object sender, EventArgs e)
        {
            //get comboBox data ("cbobxCmnt") from Comment   [ Display reviewerName in the comboBox ]
            var revName = db.Comments.Select(d => new { d.Id, Name = d.PeerReview.Reviewer.Name }).ToList();

            cbobxCmnt.DataSource = revName;
            cbobxCmnt.DisplayMember = "Name";
            cbobxCmnt.ValueMember = "Id";     //[ This will be used for setting "commentId" field in the Rating table ]

            
            //get comboBox data ("cbobxDoc") from Research Work   [ Display researchDocName in the comboBox ]
            var resrchDocName = db.ResearchWorks.Select(d => new { d.Id, d.Doc }).ToList();

            cbobxDoc.DataSource = resrchDocName;
            cbobxDoc.DisplayMember = "Doc";
            cbobxDoc.ValueMember = "Id";     //[ This will be used for setting the "authorDocId" field in the Rating table ]
        }

        private void hScrollBarRating_Scroll(object sender, ScrollEventArgs e)
        {
            lblRating.Text = hScrollBarRating.Value.ToString();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Rating RT = new Rating();

            RT.RatingValue = hScrollBarRating.Value;
            RT.commentId = Int32.Parse(cbobxCmnt.SelectedValue.ToString());
            RT.authorDocId = Int32.Parse(cbobxDoc.SelectedValue.ToString());

            db.Ratings.Add(RT);
            db.SaveChanges();

            txtbxRatingInfoId.Text = RT.Id.ToString();
            MessageBox.Show("Data Save Successfully ...");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
