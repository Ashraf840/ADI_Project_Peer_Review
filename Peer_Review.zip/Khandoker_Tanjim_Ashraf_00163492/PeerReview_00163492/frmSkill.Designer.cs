﻿namespace PeerReview_00163492
{
    partial class frmSkill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtbxSkillDesc = new System.Windows.Forms.TextBox();
            this.txtbxSkillName = new System.Windows.Forms.TextBox();
            this.lblSkillDesc = new System.Windows.Forms.Label();
            this.txtbxSkillId = new System.Windows.Forms.TextBox();
            this.lblSkillName = new System.Windows.Forms.Label();
            this.lblSkillId = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtbxSkillDesc);
            this.groupBox1.Controls.Add(this.txtbxSkillName);
            this.groupBox1.Controls.Add(this.lblSkillDesc);
            this.groupBox1.Controls.Add(this.txtbxSkillId);
            this.groupBox1.Controls.Add(this.lblSkillName);
            this.groupBox1.Controls.Add(this.lblSkillId);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(383, 267);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Skill Information";
            // 
            // txtbxSkillDesc
            // 
            this.txtbxSkillDesc.Location = new System.Drawing.Point(156, 140);
            this.txtbxSkillDesc.Multiline = true;
            this.txtbxSkillDesc.Name = "txtbxSkillDesc";
            this.txtbxSkillDesc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtbxSkillDesc.Size = new System.Drawing.Size(221, 114);
            this.txtbxSkillDesc.TabIndex = 2;
            // 
            // txtbxSkillName
            // 
            this.txtbxSkillName.Location = new System.Drawing.Point(156, 95);
            this.txtbxSkillName.Name = "txtbxSkillName";
            this.txtbxSkillName.Size = new System.Drawing.Size(221, 22);
            this.txtbxSkillName.TabIndex = 1;
            // 
            // lblSkillDesc
            // 
            this.lblSkillDesc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSkillDesc.Location = new System.Drawing.Point(20, 140);
            this.lblSkillDesc.Name = "lblSkillDesc";
            this.lblSkillDesc.Size = new System.Drawing.Size(115, 25);
            this.lblSkillDesc.TabIndex = 0;
            this.lblSkillDesc.Text = "Description:";
            this.lblSkillDesc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbxSkillId
            // 
            this.txtbxSkillId.Location = new System.Drawing.Point(156, 50);
            this.txtbxSkillId.Name = "txtbxSkillId";
            this.txtbxSkillId.ReadOnly = true;
            this.txtbxSkillId.Size = new System.Drawing.Size(100, 22);
            this.txtbxSkillId.TabIndex = 5;
            // 
            // lblSkillName
            // 
            this.lblSkillName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSkillName.Location = new System.Drawing.Point(20, 95);
            this.lblSkillName.Name = "lblSkillName";
            this.lblSkillName.Size = new System.Drawing.Size(115, 25);
            this.lblSkillName.TabIndex = 0;
            this.lblSkillName.Text = "Skill Name:";
            this.lblSkillName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSkillId
            // 
            this.lblSkillId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSkillId.Location = new System.Drawing.Point(20, 50);
            this.lblSkillId.Name = "lblSkillId";
            this.lblSkillId.Size = new System.Drawing.Size(115, 25);
            this.lblSkillId.TabIndex = 0;
            this.lblSkillId.Text = "Skill Id:";
            this.lblSkillId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(101, 301);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(83, 34);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(12, 301);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(83, 34);
            this.btnSubmit.TabIndex = 3;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // frmSkill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(415, 347);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSubmit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSkill";
            this.Text = "Skills";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtbxSkillDesc;
        private System.Windows.Forms.TextBox txtbxSkillName;
        private System.Windows.Forms.Label lblSkillDesc;
        private System.Windows.Forms.TextBox txtbxSkillId;
        private System.Windows.Forms.Label lblSkillName;
        private System.Windows.Forms.Label lblSkillId;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSubmit;
    }
}