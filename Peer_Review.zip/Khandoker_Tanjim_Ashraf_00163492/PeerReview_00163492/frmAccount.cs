﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    public partial class frmAccount : Form
    {
        //This form is used to ******** add Users ********


        //Global Declaration Area

        //create an object of PeerReviewEntities(DB object) which is inside the
        //Model1.edmx -> Model1.Context.tt -> Model1.Context.cs
        PeerReviewEntities db = new PeerReviewEntities();


        public frmAccount()
        {
            InitializeComponent();
        }

        private void frmAccount_Load(object sender, EventArgs e)
        {
            IEnumerable<UserRole> data;

            //condition to check whether the user logged in as an admin or not
            //if the user doesn't logged as an admin, the user won't have the privilige to select 
            //userType from the comboBox naming "cbobxUsrType"
            if (clsUserData.RoleName == "Admin")
            {
                data = db.UserRoles.ToList();
            }
            else
            {
                data = db.UserRoles.Where(d => d.Name != "Admin").ToList();
            }

            //displays all the allowed user-role name inside the comboBox "cbobxUsrType"
            cbobxUsrType.DisplayMember = "Name";
            cbobxUsrType.ValueMember = "Id";
            cbobxUsrType.DataSource = data;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                /*
                 *
                 * ****************** Give proper insert validation ******************
                 * 
                 */
                UserInfo uInfo = new UserInfo();

                uInfo.Name = txtbxUsrName.Text;
                uInfo.Email = txtbxUsrEmail.Text;
                uInfo.Pass = txtbxUsrPass.Text;
                uInfo.usrRoleId = Int32.Parse(cbobxUsrType.SelectedValue.ToString());


                db.UserInfoes.Add(uInfo);
                db.SaveChanges();

                txtbxUsrId.Text = uInfo.Id.ToString();
                MessageBox.Show("Data Inserted Successfully!", "Insert",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                //if (uInfo.Name != "" && uInfo.Email != "" && uInfo.Pass != "")
                //{
                //    db.UserInfoes.Add(uInfo);
                //    db.SaveChanges();

                //    if (uInfo.Id != 0)
                //    {
                //        //the Id textBox (read-only) is assigned to the next Id number which is fetched from the database
                //        txtbxUsrId.Text = uInfo.Id.ToString();
                //        MessageBox.Show("Data Inserted Successfully!", "Insert",
                //            MessageBoxButtons.OK, MessageBoxIcon.Information);
                //    }
                //    else
                //    {
                //        MessageBox.Show("Data already exists !", "Warning",
                //            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    }
                //}                
                //else
                //{
                //    MessageBox.Show("Field/s is empty!!", "Warning",
                //            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    return;
                //}

            }
            catch (Exception)
            {
                MessageBox.Show("Data insert unsuccessful!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            //firstly, close this particular form.            
            this.Hide();

            if (clsUserData.UserId == 0)
            {
                frmLogin fLogin = new frmLogin();
                fLogin.ShowDialog();
            }            
        }

        
    }
}
