﻿namespace PeerReview_00163492
{
    partial class frmComment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.txtbxCmntId = new System.Windows.Forms.TextBox();
            this.lblDOCmnt = new System.Windows.Forms.Label();
            this.lblPReviewId = new System.Windows.Forms.Label();
            this.lblCmntId = new System.Windows.Forms.Label();
            this.dtpDateOfCmnt = new System.Windows.Forms.DateTimePicker();
            this.lblRemark = new System.Windows.Forms.Label();
            this.txtbxRemark = new System.Windows.Forms.TextBox();
            this.cbobxPReviewId = new System.Windows.Forms.ComboBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbobxPReviewId);
            this.groupBox1.Controls.Add(this.dtpDateOfCmnt);
            this.groupBox1.Controls.Add(this.txtbxRemark);
            this.groupBox1.Controls.Add(this.txtbxCmntId);
            this.groupBox1.Controls.Add(this.lblRemark);
            this.groupBox1.Controls.Add(this.lblDOCmnt);
            this.groupBox1.Controls.Add(this.lblPReviewId);
            this.groupBox1.Controls.Add(this.lblCmntId);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(435, 335);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Create Comment";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(12, 367);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(125, 34);
            this.btnSubmit.TabIndex = 3;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // txtbxCmntId
            // 
            this.txtbxCmntId.Location = new System.Drawing.Point(153, 42);
            this.txtbxCmntId.Name = "txtbxCmntId";
            this.txtbxCmntId.ReadOnly = true;
            this.txtbxCmntId.Size = new System.Drawing.Size(100, 22);
            this.txtbxCmntId.TabIndex = 1;
            // 
            // lblDOCmnt
            // 
            this.lblDOCmnt.AutoSize = true;
            this.lblDOCmnt.Location = new System.Drawing.Point(11, 290);
            this.lblDOCmnt.Name = "lblDOCmnt";
            this.lblDOCmnt.Size = new System.Drawing.Size(121, 17);
            this.lblDOCmnt.TabIndex = 0;
            this.lblDOCmnt.Text = "Date of Comment:";
            // 
            // lblPReviewId
            // 
            this.lblPReviewId.AutoSize = true;
            this.lblPReviewId.Location = new System.Drawing.Point(19, 85);
            this.lblPReviewId.Name = "lblPReviewId";
            this.lblPReviewId.Size = new System.Drawing.Size(106, 17);
            this.lblPReviewId.TabIndex = 0;
            this.lblPReviewId.Text = "Peer Review Id:";
            // 
            // lblCmntId
            // 
            this.lblCmntId.AutoSize = true;
            this.lblCmntId.Location = new System.Drawing.Point(46, 45);
            this.lblCmntId.Name = "lblCmntId";
            this.lblCmntId.Size = new System.Drawing.Size(86, 17);
            this.lblCmntId.TabIndex = 0;
            this.lblCmntId.Text = "Comment Id:";
            // 
            // dtpDateOfCmnt
            // 
            this.dtpDateOfCmnt.CustomFormat = "yyyy/MM/dd";
            this.dtpDateOfCmnt.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDateOfCmnt.Location = new System.Drawing.Point(153, 290);
            this.dtpDateOfCmnt.Name = "dtpDateOfCmnt";
            this.dtpDateOfCmnt.Size = new System.Drawing.Size(124, 22);
            this.dtpDateOfCmnt.TabIndex = 4;
            // 
            // lblRemark
            // 
            this.lblRemark.AutoSize = true;
            this.lblRemark.Location = new System.Drawing.Point(71, 125);
            this.lblRemark.Name = "lblRemark";
            this.lblRemark.Size = new System.Drawing.Size(61, 17);
            this.lblRemark.TabIndex = 0;
            this.lblRemark.Text = "Remark:";
            // 
            // txtbxRemark
            // 
            this.txtbxRemark.Location = new System.Drawing.Point(153, 125);
            this.txtbxRemark.Multiline = true;
            this.txtbxRemark.Name = "txtbxRemark";
            this.txtbxRemark.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtbxRemark.Size = new System.Drawing.Size(269, 138);
            this.txtbxRemark.TabIndex = 1;
            // 
            // cbobxPReviewId
            // 
            this.cbobxPReviewId.FormattingEnabled = true;
            this.cbobxPReviewId.Location = new System.Drawing.Point(153, 85);
            this.cbobxPReviewId.Name = "cbobxPReviewId";
            this.cbobxPReviewId.Size = new System.Drawing.Size(207, 24);
            this.cbobxPReviewId.TabIndex = 5;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(164, 367);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(125, 34);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "&Cancel";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmComment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(465, 418);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmComment";
            this.Text = "Comment";
            this.Load += new System.EventHandler(this.frmComment_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtbxCmntId;
        private System.Windows.Forms.Label lblDOCmnt;
        private System.Windows.Forms.Label lblPReviewId;
        private System.Windows.Forms.Label lblCmntId;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.DateTimePicker dtpDateOfCmnt;
        private System.Windows.Forms.TextBox txtbxRemark;
        private System.Windows.Forms.Label lblRemark;
        private System.Windows.Forms.ComboBox cbobxPReviewId;
        private System.Windows.Forms.Button btnClose;
    }
}