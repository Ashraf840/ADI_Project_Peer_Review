﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492.List
{
    public partial class frmAuthorList : Form
    {
        PeerReviewEntities db = new PeerReviewEntities();

        public frmAuthorList()
        {
            InitializeComponent();
        }

        private void frmAuthorList_Load(object sender, EventArgs e)
        {

            if (clsUserData.RoleName.ToLower() != "Admin".ToLower())
            {
                //get the particular author Id, who logged into the system.
                //inside the where condition, it is matching the logged in userId(which is temporarily stored inside the "clsUserData" class) 
                //with its userId atore inside the "Author" table inside db (which is fetched from the "UserInfo" table as an fk naming "usrId" inside the "Author" table)
                var authr = db.Authors.Where(d => d.usrId == clsUserData.UserId ).FirstOrDefault();

                //FACT-1(select): fetching all the fields of Author through "AuthorSkill" table, since the "AuthorSkill" 
                //table is interconnected with bothe the "Author" & "Skill" table. This "AuthorSkill" 
                //table works like a bridge.
                //FACT-2(where): the author can only see his/her information.
                var data = db.AuthorSkills.Select(d => new { d.Author.Id, d.Author.Name, d.Author.Email, d.Author.DOB, Skill = d.Skill.Name }).Where(d => d.Id == authr.Id).ToList();
                //BRIEF: an anonymous type cannot have multiple properties with the same name. 
                //So I need to store the name of the skills (skill.name) into another variable, 
                //because the "d" is holding another property with the same name. I'm using a variable naming skill.

                dgvAuthorList.DataSource = null;
                dgvAuthorList.DataSource = data;
            }
            else
            {
                var data = db.AuthorSkills.Select(d => new { d.Author.Id, d.Author.Name, d.Author.Email, d.Author.DOB, skill = d.Skill.Name }).ToList();
                dgvAuthorList.DataSource = null;
                dgvAuthorList.DataSource = data;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
