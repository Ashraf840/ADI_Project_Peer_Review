﻿namespace PeerReview_00163492.List
{
    partial class frmAssignedResearchWorkList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.lblAssgnRWLst = new System.Windows.Forms.Label();
            this.dgvAssgnRWLst = new System.Windows.Forms.DataGridView();
            this.btnAssigned = new System.Windows.Forms.Button();
            this.btnUnassigned = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssgnRWLst)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Location = new System.Drawing.Point(860, 405);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(105, 33);
            this.btnClose.TabIndex = 8;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblAssgnRWLst
            // 
            this.lblAssgnRWLst.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAssgnRWLst.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAssgnRWLst.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssgnRWLst.Location = new System.Drawing.Point(12, 18);
            this.lblAssgnRWLst.Name = "lblAssgnRWLst";
            this.lblAssgnRWLst.Size = new System.Drawing.Size(953, 46);
            this.lblAssgnRWLst.TabIndex = 7;
            this.lblAssgnRWLst.Text = "Assigned Research Work List";
            this.lblAssgnRWLst.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvAssgnRWLst
            // 
            this.dgvAssgnRWLst.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvAssgnRWLst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAssgnRWLst.Location = new System.Drawing.Point(12, 88);
            this.dgvAssgnRWLst.Name = "dgvAssgnRWLst";
            this.dgvAssgnRWLst.RowTemplate.Height = 24;
            this.dgvAssgnRWLst.Size = new System.Drawing.Size(953, 285);
            this.dgvAssgnRWLst.TabIndex = 6;
            // 
            // btnAssigned
            // 
            this.btnAssigned.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAssigned.Location = new System.Drawing.Point(707, 405);
            this.btnAssigned.Name = "btnAssigned";
            this.btnAssigned.Size = new System.Drawing.Size(105, 33);
            this.btnAssigned.TabIndex = 8;
            this.btnAssigned.Text = "&Assigned";
            this.btnAssigned.UseVisualStyleBackColor = true;
            this.btnAssigned.Click += new System.EventHandler(this.btnAssigned_Click);
            // 
            // btnUnassigned
            // 
            this.btnUnassigned.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUnassigned.Location = new System.Drawing.Point(550, 405);
            this.btnUnassigned.Name = "btnUnassigned";
            this.btnUnassigned.Size = new System.Drawing.Size(105, 33);
            this.btnUnassigned.TabIndex = 8;
            this.btnUnassigned.Text = "&Unassigned";
            this.btnUnassigned.UseVisualStyleBackColor = true;
            this.btnUnassigned.Click += new System.EventHandler(this.btnUnassigned_Click);
            // 
            // frmAssignedResearchWorkList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(977, 450);
            this.Controls.Add(this.btnUnassigned);
            this.Controls.Add(this.btnAssigned);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblAssgnRWLst);
            this.Controls.Add(this.dgvAssgnRWLst);
            this.Name = "frmAssignedResearchWorkList";
            this.Text = "Assigned Document List";
            this.Load += new System.EventHandler(this.frmAssignedResearchWorkList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssgnRWLst)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblAssgnRWLst;
        private System.Windows.Forms.DataGridView dgvAssgnRWLst;
        private System.Windows.Forms.Button btnAssigned;
        private System.Windows.Forms.Button btnUnassigned;
    }
}