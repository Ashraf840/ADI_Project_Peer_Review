﻿namespace PeerReview_00163492.List
{
    partial class frmCommentInfoList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.lblCommentList = new System.Windows.Forms.Label();
            this.dgvCommentList = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCommentList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Location = new System.Drawing.Point(860, 402);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(105, 33);
            this.btnClose.TabIndex = 11;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblCommentList
            // 
            this.lblCommentList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCommentList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCommentList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCommentList.Location = new System.Drawing.Point(12, 15);
            this.lblCommentList.Name = "lblCommentList";
            this.lblCommentList.Size = new System.Drawing.Size(953, 46);
            this.lblCommentList.TabIndex = 10;
            this.lblCommentList.Text = "List of Comments Information";
            this.lblCommentList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvCommentList
            // 
            this.dgvCommentList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvCommentList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCommentList.Location = new System.Drawing.Point(12, 90);
            this.dgvCommentList.Name = "dgvCommentList";
            this.dgvCommentList.RowTemplate.Height = 24;
            this.dgvCommentList.Size = new System.Drawing.Size(953, 285);
            this.dgvCommentList.TabIndex = 9;
            // 
            // frmComentInfoList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(977, 450);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblCommentList);
            this.Controls.Add(this.dgvCommentList);
            this.Name = "frmComentInfoList";
            this.Text = "Coment Information List";
            this.Load += new System.EventHandler(this.frmComentInfoList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCommentList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblCommentList;
        private System.Windows.Forms.DataGridView dgvCommentList;
    }
}