﻿namespace PeerReview_00163492.List
{
    partial class frmReviewerList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.lblReviewerList = new System.Windows.Forms.Label();
            this.dgvReviewerList = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReviewerList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Location = new System.Drawing.Point(860, 402);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(105, 33);
            this.btnClose.TabIndex = 8;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblReviewerList
            // 
            this.lblReviewerList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblReviewerList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblReviewerList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReviewerList.Location = new System.Drawing.Point(12, 15);
            this.lblReviewerList.Name = "lblReviewerList";
            this.lblReviewerList.Size = new System.Drawing.Size(953, 46);
            this.lblReviewerList.TabIndex = 7;
            this.lblReviewerList.Text = "List of Reviewers Information";
            this.lblReviewerList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvReviewerList
            // 
            this.dgvReviewerList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvReviewerList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReviewerList.Location = new System.Drawing.Point(12, 90);
            this.dgvReviewerList.Name = "dgvReviewerList";
            this.dgvReviewerList.RowTemplate.Height = 24;
            this.dgvReviewerList.Size = new System.Drawing.Size(953, 285);
            this.dgvReviewerList.TabIndex = 6;
            // 
            // frmReviewerList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(977, 450);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblReviewerList);
            this.Controls.Add(this.dgvReviewerList);
            this.Name = "frmReviewerList";
            this.Text = "Reviewer List";
            this.Load += new System.EventHandler(this.frmReviewerList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReviewerList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblReviewerList;
        private System.Windows.Forms.DataGridView dgvReviewerList;
    }
}