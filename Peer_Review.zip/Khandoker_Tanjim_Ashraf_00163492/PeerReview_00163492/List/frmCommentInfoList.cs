﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492.List
{
    public partial class frmCommentInfoList : Form
    {

        PeerReviewEntities db = new PeerReviewEntities();

        public frmCommentInfoList()
        {
            InitializeComponent();
        }

        private void frmComentInfoList_Load(object sender, EventArgs e)
        {
            var data = db.Comments.Select(d => new { d.Id, d.peerRevId, d.Remark, d.cmntDate }).ToList();

            dgvCommentList.DataSource = data;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
