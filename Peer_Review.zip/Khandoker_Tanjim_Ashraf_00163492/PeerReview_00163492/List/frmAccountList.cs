﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492.List
{
    public partial class frmAccountList : Form
    {

        //Global Declaration Area

        //create an object of PeerReviewEntities(DB object) which is inside the
        //Model1.edmx -> Model1.Context.tt -> Model1.Context.cs
        PeerReviewEntities db = new PeerReviewEntities();

        public frmAccountList()
        {
            InitializeComponent();
        }

        private void frmAccountList_Load(object sender, EventArgs e)
        {
            if (clsUserData.RoleName.ToLower() != "Admin".ToLower())
            {
                var data = db.UserInfoes.Select(d => new
                {
                    d.Id,
                    d.Name,
                    d.Email,
                    Pass = "*****".ToString(),
                    UserType = d.UserRole.Name
                }).ToList();

                dgvUsrList.DataSource = null;
                dgvUsrList.DataSource = data;
            }
            else
            {
                //create an object from "PeerReviewEntities" class and also setting boundaries to display particular columns.
                var data = db.UserInfoes.Select(d => new
                {
                    d.Id,
                    d.Name,
                    d.Email,
                    Pass = d.Pass,
                    UserType = d.UserRole.Name
                }).ToList();

                dgvUsrList.DataSource = null;
                dgvUsrList.DataSource = data;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
