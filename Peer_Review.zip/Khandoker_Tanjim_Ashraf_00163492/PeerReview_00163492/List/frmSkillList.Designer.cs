﻿namespace PeerReview_00163492.List
{
    partial class frmSkillList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.lblSkillList = new System.Windows.Forms.Label();
            this.dgvUsrSkillList = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsrSkillList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Location = new System.Drawing.Point(537, 413);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(105, 33);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblSkillList
            // 
            this.lblSkillList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSkillList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSkillList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSkillList.Location = new System.Drawing.Point(12, 22);
            this.lblSkillList.Name = "lblSkillList";
            this.lblSkillList.Size = new System.Drawing.Size(630, 46);
            this.lblSkillList.TabIndex = 4;
            this.lblSkillList.Text = "List of Skill Information";
            this.lblSkillList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvUsrSkillList
            // 
            this.dgvUsrSkillList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvUsrSkillList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsrSkillList.Location = new System.Drawing.Point(12, 94);
            this.dgvUsrSkillList.Name = "dgvUsrSkillList";
            this.dgvUsrSkillList.RowTemplate.Height = 24;
            this.dgvUsrSkillList.Size = new System.Drawing.Size(630, 302);
            this.dgvUsrSkillList.TabIndex = 3;
            // 
            // frmSkillList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 467);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblSkillList);
            this.Controls.Add(this.dgvUsrSkillList);
            this.Name = "frmSkillList";
            this.Text = "Skill List";
            this.Load += new System.EventHandler(this.frmSkillList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsrSkillList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblSkillList;
        private System.Windows.Forms.DataGridView dgvUsrSkillList;
    }
}