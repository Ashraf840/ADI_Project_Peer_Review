﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    public partial class frmUserRoleList : Form
    {
        //Global Declaration Area

        PeerReviewEntities db = new PeerReviewEntities();


        public frmUserRoleList()
        {
            InitializeComponent();
        }


        private void frmUserRoleList_Load(object sender, EventArgs e)
        {
            //create an object from "PeerReviewEntities" class and also setting boundaries to display particular columns.
            var data = db.UserRoles.Select(d => new {d.Id, d.Name}).ToList();

            dgvUsrRoleLst.DataSource = null;
            dgvUsrRoleLst.DataSource = data;           
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
