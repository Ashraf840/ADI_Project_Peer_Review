﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492.List
{
    public partial class frmAssignedResearchWorkList : Form
    {

        PeerReviewEntities db = new PeerReviewEntities();

        public frmAssignedResearchWorkList()
        {
            InitializeComponent();
        }

        private void frmAssignedResearchWorkList_Load(object sender, EventArgs e)
        {
            var data = db.ResearchWorks.Select(d => new { d.Id, d.Doc, d.uDate, d.dType, Skill = d.Skill.Name, Author = d.Author.Name, d.isReviewer }).Where(d => d.isReviewer == false).ToList();

            dgvAssgnRWLst.DataSource = null;
            dgvAssgnRWLst.DataSource = data;
        }


        private void btnAssigned_Click(object sender, EventArgs e)
        {
            var data = db.ResearchWorks.Select(d => new { d.Id, d.Doc, d.uDate, d.dType, Skill = d.Skill.Name, Author = d.Author.Name, d.isReviewer }).Where(d => d.isReviewer == true).ToList();

            dgvAssgnRWLst.DataSource = null;
            dgvAssgnRWLst.DataSource = data;
        }

        private void btnUnassigned_Click(object sender, EventArgs e)
        {
            var data = db.ResearchWorks.Select(d => new { d.Id, d.Doc, d.uDate, d.dType, Skill = d.Skill.Name, Author = d.Author.Name, d.isReviewer }).Where(d => d.isReviewer == false).ToList();

            dgvAssgnRWLst.DataSource = null;
            dgvAssgnRWLst.DataSource = data;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
