﻿namespace PeerReview_00163492.List
{
    partial class frmSearchList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSrchCmntLst = new System.Windows.Forms.Label();
            this.lblSrchWrd = new System.Windows.Forms.Label();
            this.txtbxSrchWrd = new System.Windows.Forms.TextBox();
            this.btnSrchWrd = new System.Windows.Forms.Button();
            this.dgvSrchCmntWrd = new System.Windows.Forms.DataGridView();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSrchCmntWrd)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSrchCmntLst
            // 
            this.lblSrchCmntLst.AutoSize = true;
            this.lblSrchCmntLst.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSrchCmntLst.Location = new System.Drawing.Point(212, 29);
            this.lblSrchCmntLst.Name = "lblSrchCmntLst";
            this.lblSrchCmntLst.Size = new System.Drawing.Size(286, 32);
            this.lblSrchCmntLst.TabIndex = 0;
            this.lblSrchCmntLst.Text = "Search Comment List";
            // 
            // lblSrchWrd
            // 
            this.lblSrchWrd.AutoSize = true;
            this.lblSrchWrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSrchWrd.Location = new System.Drawing.Point(12, 106);
            this.lblSrchWrd.Name = "lblSrchWrd";
            this.lblSrchWrd.Size = new System.Drawing.Size(107, 17);
            this.lblSrchWrd.TabIndex = 0;
            this.lblSrchWrd.Text = "Search Word:";
            // 
            // txtbxSrchWrd
            // 
            this.txtbxSrchWrd.Location = new System.Drawing.Point(125, 103);
            this.txtbxSrchWrd.Name = "txtbxSrchWrd";
            this.txtbxSrchWrd.Size = new System.Drawing.Size(468, 22);
            this.txtbxSrchWrd.TabIndex = 1;
            // 
            // btnSrchWrd
            // 
            this.btnSrchWrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSrchWrd.Location = new System.Drawing.Point(599, 99);
            this.btnSrchWrd.Name = "btnSrchWrd";
            this.btnSrchWrd.Size = new System.Drawing.Size(114, 30);
            this.btnSrchWrd.TabIndex = 2;
            this.btnSrchWrd.Text = "Search";
            this.btnSrchWrd.UseVisualStyleBackColor = true;
            // 
            // dgvSrchCmntWrd
            // 
            this.dgvSrchCmntWrd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSrchCmntWrd.Location = new System.Drawing.Point(15, 142);
            this.dgvSrchCmntWrd.Name = "dgvSrchCmntWrd";
            this.dgvSrchCmntWrd.RowTemplate.Height = 24;
            this.dgvSrchCmntWrd.Size = new System.Drawing.Size(698, 263);
            this.dgvSrchCmntWrd.TabIndex = 3;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(15, 424);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(698, 40);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmSearchList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(725, 485);
            this.Controls.Add(this.dgvSrchCmntWrd);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSrchWrd);
            this.Controls.Add(this.txtbxSrchWrd);
            this.Controls.Add(this.lblSrchWrd);
            this.Controls.Add(this.lblSrchCmntLst);
            this.Name = "frmSearchList";
            this.Text = "Search List";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSrchCmntWrd)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSrchCmntLst;
        private System.Windows.Forms.Label lblSrchWrd;
        private System.Windows.Forms.TextBox txtbxSrchWrd;
        private System.Windows.Forms.Button btnSrchWrd;
        private System.Windows.Forms.DataGridView dgvSrchCmntWrd;
        private System.Windows.Forms.Button btnClose;
    }
}