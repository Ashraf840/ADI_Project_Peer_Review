﻿namespace PeerReview_00163492.List
{
    partial class frmConferenceInfoList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.lblResearchWrkList = new System.Windows.Forms.Label();
            this.dgvResearchWrkList = new System.Windows.Forms.DataGridView();
            this.btnPrevEvent = new System.Windows.Forms.Button();
            this.btnUpcomingEvent = new System.Windows.Forms.Button();
            this.btnViewAllEvent = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResearchWrkList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Location = new System.Drawing.Point(860, 520);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(105, 33);
            this.btnClose.TabIndex = 11;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // lblResearchWrkList
            // 
            this.lblResearchWrkList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblResearchWrkList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResearchWrkList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResearchWrkList.Location = new System.Drawing.Point(12, 88);
            this.lblResearchWrkList.Name = "lblResearchWrkList";
            this.lblResearchWrkList.Size = new System.Drawing.Size(953, 46);
            this.lblResearchWrkList.TabIndex = 10;
            this.lblResearchWrkList.Text = "List of Research Works";
            this.lblResearchWrkList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvResearchWrkList
            // 
            this.dgvResearchWrkList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvResearchWrkList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResearchWrkList.Location = new System.Drawing.Point(12, 157);
            this.dgvResearchWrkList.Name = "dgvResearchWrkList";
            this.dgvResearchWrkList.RowTemplate.Height = 24;
            this.dgvResearchWrkList.Size = new System.Drawing.Size(953, 341);
            this.dgvResearchWrkList.TabIndex = 9;
            // 
            // btnPrevEvent
            // 
            this.btnPrevEvent.Location = new System.Drawing.Point(12, 35);
            this.btnPrevEvent.Name = "btnPrevEvent";
            this.btnPrevEvent.Size = new System.Drawing.Size(130, 29);
            this.btnPrevEvent.TabIndex = 12;
            this.btnPrevEvent.Text = "Previous Event";
            this.btnPrevEvent.UseVisualStyleBackColor = true;
            this.btnPrevEvent.Click += new System.EventHandler(this.btnPrevEvent_Click);
            // 
            // btnUpcomingEvent
            // 
            this.btnUpcomingEvent.Location = new System.Drawing.Point(148, 35);
            this.btnUpcomingEvent.Name = "btnUpcomingEvent";
            this.btnUpcomingEvent.Size = new System.Drawing.Size(130, 29);
            this.btnUpcomingEvent.TabIndex = 13;
            this.btnUpcomingEvent.Text = "Upcoming Event";
            this.btnUpcomingEvent.UseVisualStyleBackColor = true;
            this.btnUpcomingEvent.Click += new System.EventHandler(this.btnUpcomingEvent_Click);
            // 
            // btnViewAllEvent
            // 
            this.btnViewAllEvent.Location = new System.Drawing.Point(860, 35);
            this.btnViewAllEvent.Name = "btnViewAllEvent";
            this.btnViewAllEvent.Size = new System.Drawing.Size(105, 29);
            this.btnViewAllEvent.TabIndex = 14;
            this.btnViewAllEvent.Text = "View All";
            this.btnViewAllEvent.UseVisualStyleBackColor = true;
            this.btnViewAllEvent.Click += new System.EventHandler(this.btnViewAllEvent_Click);
            // 
            // frmConferenceInfoList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(977, 563);
            this.Controls.Add(this.btnViewAllEvent);
            this.Controls.Add(this.btnUpcomingEvent);
            this.Controls.Add(this.btnPrevEvent);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblResearchWrkList);
            this.Controls.Add(this.dgvResearchWrkList);
            this.Name = "frmConferenceInfoList";
            this.Text = "Conference Information List";
            this.Load += new System.EventHandler(this.frmConferenceInfoList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResearchWrkList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblResearchWrkList;
        private System.Windows.Forms.DataGridView dgvResearchWrkList;
        private System.Windows.Forms.Button btnPrevEvent;
        private System.Windows.Forms.Button btnUpcomingEvent;
        private System.Windows.Forms.Button btnViewAllEvent;
    }
}