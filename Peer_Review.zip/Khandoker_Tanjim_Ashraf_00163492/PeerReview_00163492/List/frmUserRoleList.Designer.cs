﻿namespace PeerReview_00163492
{
    partial class frmUserRoleList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvUsrRoleLst = new System.Windows.Forms.DataGridView();
            this.lblUsrRoleList = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsrRoleLst)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvUsrRoleLst
            // 
            this.dgvUsrRoleLst.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvUsrRoleLst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsrRoleLst.Location = new System.Drawing.Point(12, 100);
            this.dgvUsrRoleLst.Name = "dgvUsrRoleLst";
            this.dgvUsrRoleLst.RowTemplate.Height = 24;
            this.dgvUsrRoleLst.Size = new System.Drawing.Size(953, 268);
            this.dgvUsrRoleLst.TabIndex = 0;
            // 
            // lblUsrRoleList
            // 
            this.lblUsrRoleList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblUsrRoleList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUsrRoleList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsrRoleList.Location = new System.Drawing.Point(12, 28);
            this.lblUsrRoleList.Name = "lblUsrRoleList";
            this.lblUsrRoleList.Size = new System.Drawing.Size(953, 46);
            this.lblUsrRoleList.TabIndex = 1;
            this.lblUsrRoleList.Text = "List of All User Role Information";
            this.lblUsrRoleList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Location = new System.Drawing.Point(860, 392);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(105, 33);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmUserRoleList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(977, 450);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblUsrRoleList);
            this.Controls.Add(this.dgvUsrRoleLst);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmUserRoleList";
            this.Text = "User Role List";
            this.Load += new System.EventHandler(this.frmUserRoleList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsrRoleLst)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvUsrRoleLst;
        private System.Windows.Forms.Label lblUsrRoleList;
        private System.Windows.Forms.Button btnClose;
    }
}