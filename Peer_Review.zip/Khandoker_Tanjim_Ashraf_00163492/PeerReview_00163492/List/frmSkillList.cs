﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492.List
{
    public partial class frmSkillList : Form
    {

        //Global Declaration Area

        //create an object of PeerReviewEntities(DB object) which is inside the
        //Model1.edmx -> Model1.Context.tt -> Model1.Context.cs
        PeerReviewEntities db = new PeerReviewEntities();

        public frmSkillList()
        {
            InitializeComponent();
        }

        private void frmSkillList_Load(object sender, EventArgs e)
        {
            //create an object from "PeerReviewEntities" class and also set boundaries to display particular columns.
            var data = db.Skills.Select(d => new { d.Id, d.Name, d.Description }).ToList();

            dgvUsrSkillList.DataSource = null;
            dgvUsrSkillList.DataSource = data;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
