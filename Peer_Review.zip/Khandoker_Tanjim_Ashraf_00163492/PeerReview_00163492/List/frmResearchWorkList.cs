﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492.List
{
    public partial class frmResearchWorkList : Form
    {

        PeerReviewEntities db = new PeerReviewEntities();

        public frmResearchWorkList()
        {
            InitializeComponent();
        }

        private void frmResearchWorkList_Load(object sender, EventArgs e)
        {
            var data = db.ResearchWorks.Select(d => new { d.Id, d.Doc, d.uDate, d.dType, Skill = d.Skill.Name, Author =  d.Author.Name }).ToList();

            dgvResearchWrkList.DataSource = data;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
