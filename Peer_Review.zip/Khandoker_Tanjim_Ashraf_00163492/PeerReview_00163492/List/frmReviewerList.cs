﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492.List
{
    public partial class frmReviewerList : Form
    {

        PeerReviewEntities db = new PeerReviewEntities();

        public frmReviewerList()
        {
            InitializeComponent();
        }

        private void frmReviewerList_Load(object sender, EventArgs e)
        {
            if (clsUserData.RoleName.ToLower() != "Admin".ToLower())
            {
                var reviewr = db.Reviewers.Where(d => d.usrId == clsUserData.UserId).FirstOrDefault();

                var data = db.ReviewerSkills.Select(d => new { d.Reviewer.Id, d.Reviewer.Name, d.Reviewer.Email, d.Reviewer.DOB, Skill = d.Skill.Name }).Where(d => d.Id == reviewr.Id).ToList();

                dgvReviewerList.DataSource = null;
                dgvReviewerList.DataSource = data;
            }
            else
            {
                var data = db.ReviewerSkills.Select(d => new { d.Reviewer.Id, d.Reviewer.Name, d.Reviewer.Email, d.Reviewer.DOB, Skill = d.Skill.Name }).ToList();
                dgvReviewerList.DataSource = null;
                dgvReviewerList.DataSource = data;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
