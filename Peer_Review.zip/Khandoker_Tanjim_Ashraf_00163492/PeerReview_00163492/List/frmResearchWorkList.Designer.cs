﻿namespace PeerReview_00163492.List
{
    partial class frmResearchWorkList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.lblResearchWrkList = new System.Windows.Forms.Label();
            this.dgvResearchWrkList = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResearchWrkList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Location = new System.Drawing.Point(860, 405);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(105, 33);
            this.btnClose.TabIndex = 8;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblResearchWrkList
            // 
            this.lblResearchWrkList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblResearchWrkList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResearchWrkList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResearchWrkList.Location = new System.Drawing.Point(12, 9);
            this.lblResearchWrkList.Name = "lblResearchWrkList";
            this.lblResearchWrkList.Size = new System.Drawing.Size(953, 46);
            this.lblResearchWrkList.TabIndex = 7;
            this.lblResearchWrkList.Text = "List of Research Works";
            this.lblResearchWrkList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvResearchWrkList
            // 
            this.dgvResearchWrkList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvResearchWrkList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResearchWrkList.Location = new System.Drawing.Point(12, 81);
            this.dgvResearchWrkList.Name = "dgvResearchWrkList";
            this.dgvResearchWrkList.RowTemplate.Height = 24;
            this.dgvResearchWrkList.Size = new System.Drawing.Size(953, 302);
            this.dgvResearchWrkList.TabIndex = 6;
            // 
            // frmResearchWorkList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(977, 450);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblResearchWrkList);
            this.Controls.Add(this.dgvResearchWrkList);
            this.Name = "frmResearchWorkList";
            this.Text = "Research Work List";
            this.Load += new System.EventHandler(this.frmResearchWorkList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResearchWrkList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblResearchWrkList;
        private System.Windows.Forms.DataGridView dgvResearchWrkList;
    }
}