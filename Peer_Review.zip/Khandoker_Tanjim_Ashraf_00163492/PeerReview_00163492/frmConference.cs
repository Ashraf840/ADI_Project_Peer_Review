﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    public partial class frmConference : Form
    {

        PeerReviewEntities db = new PeerReviewEntities();

        public frmConference()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            ProjectConference conf = new ProjectConference();

            conf.cTitle = txtbxConferenceTitle.Text;
            conf.pDescription = txtbxProjectDesc.Text;
            conf.StartDate = dtpDateOfConference.Value;

            db.ProjectConferences.Add(conf);
            db.SaveChanges();

            txtbxConferenceInfoId.Text = conf.Id.ToString();

            MessageBox.Show("Conference Created Successfully ...");
        }
    }
}
