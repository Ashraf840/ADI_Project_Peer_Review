﻿namespace PeerReview_00163492
{
    partial class frmPeerReview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dtpPRDOR = new System.Windows.Forms.DateTimePicker();
            this.lblDOR = new System.Windows.Forms.Label();
            this.lblDocId = new System.Windows.Forms.Label();
            this.txtbxPRId = new System.Windows.Forms.TextBox();
            this.lblReviewerId = new System.Windows.Forms.Label();
            this.lblPRId = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.cbobxDocId = new System.Windows.Forms.ComboBox();
            this.cbobxReviewerId = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbobxReviewerId);
            this.groupBox1.Controls.Add(this.cbobxDocId);
            this.groupBox1.Controls.Add(this.dtpPRDOR);
            this.groupBox1.Controls.Add(this.lblDOR);
            this.groupBox1.Controls.Add(this.lblDocId);
            this.groupBox1.Controls.Add(this.txtbxPRId);
            this.groupBox1.Controls.Add(this.lblReviewerId);
            this.groupBox1.Controls.Add(this.lblPRId);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(400, 234);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Peer Review";
            // 
            // dtpPRDOR
            // 
            this.dtpPRDOR.CustomFormat = "yyyy/MM/dd";
            this.dtpPRDOR.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPRDOR.Location = new System.Drawing.Point(156, 86);
            this.dtpPRDOR.Name = "dtpPRDOR";
            this.dtpPRDOR.Size = new System.Drawing.Size(124, 22);
            this.dtpPRDOR.TabIndex = 2;
            // 
            // lblDOR
            // 
            this.lblDOR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDOR.Location = new System.Drawing.Point(20, 86);
            this.lblDOR.Name = "lblDOR";
            this.lblDOR.Size = new System.Drawing.Size(115, 25);
            this.lblDOR.TabIndex = 0;
            this.lblDOR.Text = "Date of Review:";
            this.lblDOR.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDocId
            // 
            this.lblDocId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDocId.Location = new System.Drawing.Point(20, 129);
            this.lblDocId.Name = "lblDocId";
            this.lblDocId.Size = new System.Drawing.Size(115, 25);
            this.lblDocId.TabIndex = 0;
            this.lblDocId.Text = "Document:";
            this.lblDocId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbxPRId
            // 
            this.txtbxPRId.Location = new System.Drawing.Point(156, 43);
            this.txtbxPRId.Name = "txtbxPRId";
            this.txtbxPRId.ReadOnly = true;
            this.txtbxPRId.Size = new System.Drawing.Size(100, 22);
            this.txtbxPRId.TabIndex = 0;
            // 
            // lblReviewerId
            // 
            this.lblReviewerId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblReviewerId.Location = new System.Drawing.Point(20, 172);
            this.lblReviewerId.Name = "lblReviewerId";
            this.lblReviewerId.Size = new System.Drawing.Size(115, 25);
            this.lblReviewerId.TabIndex = 0;
            this.lblReviewerId.Text = "Reviewer:";
            this.lblReviewerId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPRId
            // 
            this.lblPRId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPRId.Location = new System.Drawing.Point(20, 43);
            this.lblPRId.Name = "lblPRId";
            this.lblPRId.Size = new System.Drawing.Size(115, 25);
            this.lblPRId.TabIndex = 0;
            this.lblPRId.Text = "Id:";
            this.lblPRId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(105, 264);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(83, 34);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(12, 264);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(83, 34);
            this.btnSubmit.TabIndex = 4;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // cbobxDocId
            // 
            this.cbobxDocId.FormattingEnabled = true;
            this.cbobxDocId.Location = new System.Drawing.Point(156, 129);
            this.cbobxDocId.Name = "cbobxDocId";
            this.cbobxDocId.Size = new System.Drawing.Size(226, 24);
            this.cbobxDocId.TabIndex = 1;
            this.cbobxDocId.SelectionChangeCommitted += new System.EventHandler(this.cbobxDocId_SelectionChangeCommitted);
            // 
            // cbobxReviewerId
            // 
            this.cbobxReviewerId.FormattingEnabled = true;
            this.cbobxReviewerId.Location = new System.Drawing.Point(156, 172);
            this.cbobxReviewerId.Name = "cbobxReviewerId";
            this.cbobxReviewerId.Size = new System.Drawing.Size(226, 24);
            this.cbobxReviewerId.TabIndex = 3;
            // 
            // frmPeerReview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 321);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmPeerReview";
            this.Text = "Peer Review";
            this.Load += new System.EventHandler(this.frmPeerReview_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dtpPRDOR;
        private System.Windows.Forms.Label lblDOR;
        private System.Windows.Forms.Label lblDocId;
        private System.Windows.Forms.TextBox txtbxPRId;
        private System.Windows.Forms.Label lblReviewerId;
        private System.Windows.Forms.Label lblPRId;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.ComboBox cbobxReviewerId;
        private System.Windows.Forms.ComboBox cbobxDocId;
    }
}