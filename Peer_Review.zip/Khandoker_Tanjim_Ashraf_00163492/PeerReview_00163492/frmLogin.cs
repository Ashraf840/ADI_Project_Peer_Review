﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    public partial class frmLogin : Form
    {

        PeerReviewEntities db = new PeerReviewEntities();

        public frmLogin()
        {
            InitializeComponent();
        }

        //user login button code
        private void btnLogin_Click(object sender, EventArgs e)
        {
            //******************* Validation: if the EMAIL & PASSWORD is already inside the database *******************
            //using "ToLower()" method makes the email checking case-insensitive, 
            //whereas, the password field is case-sensitive due to not using the "ToLower" format.
            var user = db.UserInfoes.Where(d => d.Email.ToLower() == txtbxEmail.Text.ToLower() &&
                                            d.Pass == txtbxPassword.Text).FirstOrDefault();


            if (user != null)
            {
                clsUserData.UserId = (int)user.Id;
                clsUserData.UserName = user.Name;
                clsUserData.UserEmail = user.Email;
                clsUserData.RoleName = user.UserRole.Name;
                

                //hide this form, but when the actual "Main form" is shown, this code hinders the user to close the entire system.
                this.Hide();

                //create an object of "frmMain()" class and show the form by calling the objectName.Show().
                frmMain fmain = new frmMain();
                fmain.Show();
            }
            else
            {
                MessageBox.Show("Not a valid user...!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }


        }

        //navigate to the "Account" form
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //hide this form (formLogin) first
            //this.Visible = false;
            this.Hide();
            //instantiate the frmAccount class object, then use the show() method for showing the user registration form.
            frmAccount faccnt = new frmAccount();
            faccnt.ShowDialog();
            //faccnt.Show();
        }

        //to close this particular form
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //it closes the entire application
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtbxPassword_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                btnLogin_Click(this, new EventArgs());
            }
        }
    }
}
