﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeerReview_00163492
{
    class clsUserData
    {
        //create 4 user-defined properties (user basic info + user role name)
        public static int UserId { get; set; }
        public static string UserName { get; set; }
        public static string UserEmail { get; set; }
        public static string RoleName { get; set; }
    }
}
