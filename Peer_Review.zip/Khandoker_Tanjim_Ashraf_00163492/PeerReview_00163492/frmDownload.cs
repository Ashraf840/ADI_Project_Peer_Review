﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    public partial class frmDownload : Form
    {

        PeerReviewEntities db = new PeerReviewEntities();

        public frmDownload()
        {
            InitializeComponent();
        }

        private void frmDownload_Load(object sender, EventArgs e)
        {
            //show doc from "Peer Review"
            //research docs which are being assigned for peer reviewing (to the currently logged in reviewer) will only be displayed to the download form.            

            //get reviewer ID
            int usrId = clsUserData.UserId;
            var revwr = db.Reviewers.Where(d => d.usrId == usrId).FirstOrDefault();
            int reviewerId = revwr.Id;

            //get data from the "PeerReview" table for showing the Doc Name list inside "cbobxDoc"
            //only the specific reviewers are allowed to download the Doc, in which he/she has been assigned to
            var DocData = db.PeerReviews.Select(d => new { d.Id, d.reviewerId, DocName = d.ResearchWork.Doc }).
                Where(dRev => dRev.reviewerId == reviewerId).ToList();

            cbobxDoc.Items.Add("----Select----");
            foreach (var item in DocData)
            {
                cbobxDoc.Items.Add(item);
            }

            //displays all the docName in the dropdown list of "cbobxDoc"
            cbobxDoc.DisplayMember = "DocName";
            cbobxDoc.ValueMember = "Id";
            cbobxDoc.SelectedIndex = 0;

            //by default, "btnDownload" & "btnViewDocument" both buttons will be disabled
            btnDownload.Enabled = false;
            btnViewDocument.Enabled = false;
        }

        private void btnDownload_Click(object sender, EventArgs e)
        {
            if (txtbxDocName == null)
            {
                MessageBox.Show("Please select a document !!!");
                return;
            }

            try
            {
                string pathDestination = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), cbobxDoc.Text);
                string pathSource = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));
                File.Copy(pathSource + "\\Upload\\" + txtbxDocName.Text, pathDestination, true);

                MessageBox.Show("Please check in desktop ....");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnViewDocument_Click(object sender, EventArgs e)
        {
            string pathSource = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));
            System.Diagnostics.Process.Start(pathSource + "\\Upload\\" + txtbxDocName.Text);
        }

        private void cbobxDoc_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbobxDoc.Text != "----Select----")
            {
                txtbxDocName.Text = cbobxDoc.Text;
                btnDownload.Enabled = true;
                btnViewDocument.Enabled = true;
            }
            else
            {
                txtbxDocName.Text = "----Select----";
                btnDownload.Enabled = false;
                btnViewDocument.Enabled = false;
            }
        }
    }
}
