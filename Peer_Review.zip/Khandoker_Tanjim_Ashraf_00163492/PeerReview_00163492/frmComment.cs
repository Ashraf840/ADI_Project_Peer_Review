﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00163492
{
    public partial class frmComment : Form
    {

        PeerReviewEntities db = new PeerReviewEntities();

        public frmComment()
        {
            InitializeComponent();
        }


        private void frmComment_Load(object sender, EventArgs e)
        {
            //get reviewer Id (by using it's userId)
            int usrId = clsUserData.UserId;
            var revwr = db.Reviewers.Where(d => d.usrId == usrId).FirstOrDefault();
            int reviewerId = revwr.Id;

            //get data for comboBox "cbobxPReviewId" from "PeerReview" table (to show the ResearchWork DocName)
            var data = db.PeerReviews.Select(d => new { d.Id, d.reviewerId, Name = d.Reviewer.Name, d.ResearchWork.Doc, d.isComment }).
                Where(p => p.reviewerId == reviewerId && p.isComment == false).ToList();

            //check if there is any data in the "PeerReview" table
            if (data.Count == 0)
            {
                MessageBox.Show("No data to comment");
                btnSubmit.Enabled = false;
                return;
            }

            //show "peerReview" data inside the comboBox "cbobxPReviewId"   [ show only those data that have assigned to that particularly logged in reviewer ]
            cbobxPReviewId.DataSource = data;
            cbobxPReviewId.DisplayMember = "Doc";
            cbobxPReviewId.ValueMember = "Id";
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //----------DB Insert----------
            Comment cmnt = new Comment();
            cmnt.peerRevId = Int32.Parse(cbobxPReviewId.SelectedValue.ToString());
            cmnt.Remark = txtbxRemark.Text;
            cmnt.cmntDate = dtpDateOfCmnt.Value;

            db.Comments.Add(cmnt);
            db.SaveChanges();

            txtbxCmntId.Text = cmnt.Id.ToString();

            //---------Update Peer Review---------
            var pData = db.PeerReviews.Where(d => d.Id == cmnt.peerRevId).FirstOrDefault();
            pData.isComment = true;
            db.SaveChanges();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
