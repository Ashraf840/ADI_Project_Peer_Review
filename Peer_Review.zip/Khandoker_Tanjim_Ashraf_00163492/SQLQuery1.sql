﻿----------------Starts from "Reviewer"
-- Create table Reviewer
CREATE TABLE [dbo].[Reviewer] (
    [Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [Name] varchar(50) NOT NULL,
	[Email] varchar(50) NOT NULL UNIQUE,
    [DOB] datetime  NULL,
	[usrId] int  NULL DEFAULT 3, 
    CONSTRAINT [FK_Reviewer_UserInfo] FOREIGN KEY ([usrId]) REFERENCES [UserInfo]([Id])	
);
GO


-- Creating table ReviewerSkill
CREATE TABLE [dbo].[ReviewerSkill] (
    [Id] int IDENTITY(1,1) PRIMARY KEY NOT NULL,
    [reviewerId] int NOT NULL,
    [skillId] int NOT NULL,
	CONSTRAINT [FK_ReviewerSkill_Reviewer] FOREIGN KEY ([reviewerId]) REFERENCES [dbo].[Reviewer] ([Id]),
    CONSTRAINT [FK_ReviewerSkill_Skill] FOREIGN KEY ([skillId]) REFERENCES [dbo].[Skill] ([Id])   	
);
GO


-- Creating table ResearchWork
CREATE TABLE [dbo].[ResearchWork] (
    [Id]    INT   IDENTITY (1, 1) PRIMARY KEY NOT NULL,
    [Doc]   VARCHAR (50) NULL,
    [uDate] DATE         NULL,
    [dType] VARCHAR (50) NULL,
	[skillId] INT        NULL,
    [authrId]   INT          NULL,
    CONSTRAINT [FK_resrchWork_Skill] FOREIGN KEY ([skillId]) REFERENCES [dbo].[Skill] ([Id]),
	CONSTRAINT [FK_resrchWork_Author] FOREIGN KEY ([authrId]) REFERENCES [dbo].[Author] ([Id])
);
GO


-- Creating table DocumentTag
CREATE TABLE [dbo].[DocumentTag] (
    [Id]    INT   IDENTITY (1, 1) PRIMARY KEY NOT NULL,
    [docId]    INT NOT NULL,
    [skillId]  INT NOT NULL,    
	CONSTRAINT [FK_dTag_resrchWork] FOREIGN KEY ([docId]) REFERENCES [ResearchWork]([Id]),
	CONSTRAINT [FK_dTag_skill] FOREIGN KEY ([skillId]) REFERENCES [Skill]([Id])
);
GO



CREATE TABLE [dbo].[PeerReview]
(
	[Id] INT IDENTITY NOT NULL PRIMARY KEY, 
    [DOR] DATE NULL,
	[reviewerId]    INT NULL,
	[docId]    INT NULL,
	CONSTRAINT [FK_PRWork_reviewr] FOREIGN KEY ([reviewerId]) REFERENCES [Reviewer]([Id]),
	CONSTRAINT [FK_PRWork_resrchWork] FOREIGN KEY ([docId]) REFERENCES [ResearchWork]([Id]),
    
);
GO



CREATE TABLE [dbo].[Comment] (
    [Id]     INT           IDENTITY (1, 1) NOT NULL,
	[peerRevId] INT NULL, 
    [Remark] VARCHAR (MAX) NULL,
    [cmntDate]  DATE          NULL,
    [skillId] INT NULL, 
	PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_cmnt_PRWork] FOREIGN KEY ([peerRevId]) REFERENCES [dbo].[PeerReview] ([Id]),
    CONSTRAINT [FK_cmnt_skill] FOREIGN KEY ([skillId]) REFERENCES [dbo].[Skill] ([Id])
);
GO



CREATE TABLE [dbo].[Rating] (
    [Id]     INT           IDENTITY (1, 1) NOT NULL PRIMARY KEY,
	[RatingValue] DECIMAL NULL,
	[commentId] INT NULL, 
	[authorDocId] INT NULL,
    CONSTRAINT [FK_Rating_cmnt] FOREIGN KEY ([commentId]) REFERENCES [dbo].[Comment] ([Id]),
    CONSTRAINT [FK_Rating_resrchWork] FOREIGN KEY ([authorDocId]) REFERENCES [dbo].[ResearchWork] ([Id])
);
GO

truncate table ResearchWork;
GO



CREATE TABLE [dbo].[Conference] (
    [Id]    INT  IDENTITY (1, 1) NOT NULL PRIMARY KEY,
    [Title]  VARCHAR (50) NULL,
    [StartDate] Date NULL    
);
Go