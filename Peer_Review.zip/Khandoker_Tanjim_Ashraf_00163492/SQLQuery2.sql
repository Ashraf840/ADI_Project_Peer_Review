﻿CREATE TABLE [dbo].[PeerReview] (
    [Id]         INT  IDENTITY (1, 1) NOT NULL,
    [DOR]        DATE NULL,
    [reviewerId] INT  NULL,
    [docId]      INT  NULL,
	[isComment] BIT NULL, 
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_PRWork_reviewr] FOREIGN KEY ([reviewerId]) REFERENCES [dbo].[Reviewer] ([Id]),
    CONSTRAINT [FK_PRWork_resrchWork] FOREIGN KEY ([docId]) REFERENCES [dbo].[ResearchWork] ([Id])
);
GO

CREATE TABLE [dbo].[ProjectConference] (
    [Id]    INT  IDENTITY (1, 1) NOT NULL PRIMARY KEY,
    [cTitle]  VARCHAR (50) NULL,
	[pDescription] VARCHAR (MAX) NULL,
    [StartDate] Date NULL    
);
Go